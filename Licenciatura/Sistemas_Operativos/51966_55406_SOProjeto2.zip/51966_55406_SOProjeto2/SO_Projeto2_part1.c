#include <stdio.h>
#include <stdlib.h>
#include "inputs_part1.c"

#define MEMORY_SIZE 20
#define FRAME_SIZE 2
#define NUM_FRAMES (MEMORY_SIZE / FRAME_SIZE)

typedef struct {
    int process_id;
    int page_number;
    int use_bit; // Bit de uso para o algoritmo CLOCK
} Frame;

Frame memory[NUM_FRAMES];

int *inputP1Mem;  // Ponteiros para os arrays de entrada escolhidos
int *inputP1Exec; 
int inputP1MemSize;  // Tamanho do array inputP1Mem
int inputP1ExecSize; // Tamanho do array inputP1Exec
int num_processes;   // Número de processos do conjunto de entrada

void initialize_memory() {
    for (int i = 0; i < NUM_FRAMES; i++) {
        memory[i].process_id = -1;
        memory[i].page_number = -1;
        memory[i].use_bit = 0; // Inicializar o bit de uso
    }
}

int find_frame_to_replace_fifo() {
    static int next_frame_to_replace = 0;
    int frame_index = next_frame_to_replace;
    next_frame_to_replace = (next_frame_to_replace + 1) % NUM_FRAMES;
    return frame_index;
}

int find_frame_to_replace_clock() {
    static int hand = 0;
    while (memory[hand].use_bit == 1) {
        memory[hand].use_bit = 0;
        hand = (hand + 1) % NUM_FRAMES;
    }
    int frame_index = hand;
    hand = (hand + 1) % NUM_FRAMES;
    return frame_index;
}

void replace_frame(int frame_index, int process_id, int page_number, int use_bit) {
    memory[frame_index].process_id = process_id;
    memory[frame_index].page_number = page_number;
    memory[frame_index].use_bit = use_bit; // Atualizar o bit de uso
}

void print_memory_state(int time_instance) {
    char buffer[NUM_FRAMES * 3 + 1];
    printf("%-10d", time_instance + 1);

    for (int i = 0; i < num_processes; i++) {
        int len = 0;
        for (int j = 0; j < NUM_FRAMES; j++) {
            if (memory[j].process_id == i + 1) {
                len += snprintf(buffer + len, sizeof(buffer) - len, "F%d,", j);
            }
        }
        if (len > 0) {
            buffer[len - 1] = '\0';
        } else {
            snprintf(buffer, sizeof(buffer), " ");
        }
        printf("|%-20s", buffer);
    }
    printf("\n");
}

int process_in_memory(int process_id) {
    for (int i = 0; i < NUM_FRAMES; i++) {
        if (memory[i].process_id == process_id) {
            memory[i].use_bit = 1; // Atualizar o bit de uso para o algoritmo CLOCK
            return 1;
        }
    }
    return 0;
}

void simulate_fifo() {
    for (int i = 0; i < inputP1ExecSize; i++) {
        int process_id = inputP1Exec[i];
        
        if (!process_in_memory(process_id)) {
            int pages_needed = (inputP1Mem[process_id - 1] + FRAME_SIZE - 1) / FRAME_SIZE;

            for (int page_number = 0; page_number < pages_needed; page_number++) {
                int frame_index = find_frame_to_replace_fifo();
                replace_frame(frame_index, process_id, page_number, 1); // FIFO não usa o bit de uso
            }
        }
        
        print_memory_state(i);
    }
}

void simulate_clock() {
    for (int i = 0; i < inputP1ExecSize; i++) {
        int process_id = inputP1Exec[i];
        
        if (!process_in_memory(process_id)) {
            int pages_needed = (inputP1Mem[process_id - 1] + FRAME_SIZE - 1) / FRAME_SIZE;

            for (int page_number = 0; page_number < pages_needed; page_number++) {
                int frame_index = find_frame_to_replace_clock();
                replace_frame(frame_index, process_id, page_number, 1); // CLOCK usa o bit de uso
            }
        } else {
            for (int j = 0; j < NUM_FRAMES; j++) {
                if (memory[j].process_id == process_id) {
                    memory[j].use_bit = 1; // Garantir que o bit de uso está atualizado
                }
            }
        }
        
        print_memory_state(i);
    }
}

void choose_inputs(int choice) {
    switch(choice) {
        case 0:
            inputP1Mem = inputP1Mem00;
            inputP1Exec = inputP1Exec00;
            inputP1MemSize = sizeof(inputP1Mem00) / sizeof(inputP1Mem00[0]);
            inputP1ExecSize = sizeof(inputP1Exec00) / sizeof(inputP1Exec00[0]);
            num_processes = 5;
            break;
        case 1:
            inputP1Mem = inputP1Mem01;
            inputP1Exec = inputP1Exec01;
            inputP1MemSize = sizeof(inputP1Mem01) / sizeof(inputP1Mem01[0]);
            inputP1ExecSize = sizeof(inputP1Exec01) / sizeof(inputP1Exec01[0]);
            num_processes = 5;
            break;
        case 2:
            inputP1Mem = inputP1Mem02;
            inputP1Exec = inputP1Exec02;
            inputP1MemSize = sizeof(inputP1Mem02) / sizeof(inputP1Mem02[0]);
            inputP1ExecSize = sizeof(inputP1Exec02) / sizeof(inputP1Exec02[0]);
            num_processes = 4;
            break;
        case 3:
            inputP1Mem = inputP1Mem03;
            inputP1Exec = inputP1Exec03;
            inputP1MemSize = sizeof(inputP1Mem03) / sizeof(inputP1Mem03[0]);
            inputP1ExecSize = sizeof(inputP1Exec03) / sizeof(inputP1Exec03[0]);
            num_processes = 7;
            break;
        case 4:
            inputP1Mem = inputP1Mem04;
            inputP1Exec = inputP1Exec04;
            inputP1MemSize = sizeof(inputP1Mem04) / sizeof(inputP1Mem04[0]);
            inputP1ExecSize = sizeof(inputP1Exec04) / sizeof(inputP1Exec04[0]);
            num_processes = 3;
            break;
        default:
            printf("Escolha inválida.\n");
            exit(1);
    }
}

int main() {
    int input_choice;
    
    printf("Escolha o conjunto de entradas (00 a 04): ");
    scanf("%d", &input_choice);
    
    choose_inputs(input_choice);
    
    printf("Simulação com algoritmo FIFO:\n");
    printf("%-10s", "time inst");
    for (int i = 0; i < num_processes; i++) {
        printf("|proc%-16d", i + 1);
    }
    printf("\n");
    
    initialize_memory();
    simulate_fifo();
    
    printf("\nSimulação com algoritmo CLOCK:\n");
    printf("%-10s", "time inst");
    for (int i = 0; i < num_processes; i++) {
        printf("|proc%-16d", i + 1);
    }
    printf("\n");
    
    initialize_memory();
    simulate_clock();

    return 0;
}