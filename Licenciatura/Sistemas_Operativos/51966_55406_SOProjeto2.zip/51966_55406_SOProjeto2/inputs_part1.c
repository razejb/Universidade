
int inputP1Mem00[] = {5, 6, 3, 6, 4};
int inputP1Exec00[] = {2, 3, 2, 1, 5, 2, 4, 5, 3, 2, 5, 2};


int inputP1Mem01[] = {6, 3, 1, 11};
int inputP1Exec01[] = {1, 2, 3, 1, 4, 2, 1, 3, 4};
    

int inputP1Mem02[] = {3, 2, 5, 5};
int inputP1Exec02[] = {1, 2, 3, 1, 4, 3, 2, 4, 1};


int inputP1Mem03[] = {4, 3, 1, 2, 3, 1, 4};
int inputP1Exec03[] = {1, 2, 3, 4, 5, 2, 3, 5, 7, 6, 2, 3, 6, 1, 3, 2, 6, 4};


int inputP1Mem04[] = {10, 11, 10};
int inputP1Exec04[] = {1, 2, 3, 3, 2, 1, 1, 2, 1, 3};
