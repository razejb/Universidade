# Simulador Gestor de Memória

**PARTE1**

Este trabalho, em C, simula dois algoritmos de substituição de páginas em memória: FIFO (First-In-First-Out) e CLOCK. O objetivo é gerenciar a memória de um sistema com base em diferentes conjuntos de entrada que especificam o uso de memória por diversos processos.

## Estrutura do Código

1. **Bibliotecas e Definições de Constantes:**

O código inclui as bibliotecas padrão necessárias e define algumas constantes importantes, como o tamanho da memória (`MEMORY_SIZE`), o tamanho de cada frame (`FRAME_SIZE`) e o número total de frames (`NUM_FRAMES`).

2. **Definição de Estruturas:**

O código define uma estrutura `Frame` para representar uma frame de memória, contendo informações como o ID do processo, o número da página e o bit de uso para o algoritmo CLOCK.

3. **Variáveis Globais:**

O código declara variáveis globais para armazenar as frames de memória, os ponteiros para os arrays de entrada, os tamanhos dos arrays de entrada e o número de processos.

4. **Funções Auxiliares:**

    - `initialize_memory`: Inicializa todas as frames de memória.

    - `find_frame_to_replace_fifo`: Encontra a próxima frame a ser substituído através do algoritmo FIFO.

    - `find_frame_to_replace_clock`: Encontra a próxima frame a ser substituída através do algoritmo CLOCK.

    - `replace_frame`: Substitui uma frame na memória.

    - `print_memory_state`: Imprime o estado atual da memória.

    - `process_in_memory`: Verifica se um processo está na memória.

5. **Funções de Simulação:**

    - `simulate_fifo`: Simula o algoritmo FIFO.

    - `simulate_clock`: Simula o algoritmo CLOCK.

## Funcionamento do Algoritmo

1. **Inicialização:** O código solicita ao utilizador que escolha um conjunto de entradas (00-04) para a simulação. Com base na escolha do mesmo, os dados de entrada correspondentes são carregados e a memória é inicializada.

2. **Simulação de Substituição de Páginas:** A simulação do algoritmo de substituição de páginas é realizada num loop principal. Em cada iteração do loop, o estado de cada frame de memória é atualizado com base nas páginas acessadas pelos processos.

3. **Encerramento da Simulação:** A simulação continua até que todas as referências de página tenham sido processadas. A cada referência de página, o estado atual da memória é impresso.

## Saída do Programa

A saída do programa é uma tabela que mostra o estado de cada frame de memória em cada momento da simulação.






# Simulador de Escalonamento e Memória

**PARTE2**

Este é um simulador de gestão de memória de processos desenvolvido em C. O código implementa um algoritmo básico de troca de processos (swapping) e simula o comportamento de vários processos concorrentes num sistema.

## Estrutura do Código

1. **Bibliotecas e Definições de Constantes:** O código inclui as bibliotecas padrão necessárias e define algumas constantes importantes, como o número máximo de instruções de um processo (`NUM_INSTRUCTIONS`), o quantum de tempo (`QUANTUM`), o tamanho da memória (`MEMORY_SIZE`), e o tamanho da página (`PAGE_SIZE`).

2. **Definição de Tipos e Estruturas de Dados:**
   - `State`: Um tipo enumerado para representar os diferentes estados de um processo (`NOTHING`, `READY`, `SW_RDY`, `EXECUTING`, `INTERRUPTIBLE`, `SW_INT`, `ZOMBIE`).
   - `Process`: Uma estrutura que representa um processo, contendo informações como as instruções, o estado atual, o contador de processos “zombies”, e o número de páginas na memória.
   - `Frame`: Uma estrutura que representa um frame na memória, contem o ID do processo que está usando o frame e o número da página.

3. **Variáveis Globais:** 
   - `AllProcesses`: Um array para armazenar todos os processos.
   - `num_programs`: O número total de programas.
   - `num_processes`: O número total de processos.
   - `ready`: Uma fila de processos prontos.
   - `memory`: Um array de frames na memória.

4. **Funções Auxiliares:**
   - `checkIsFinished`: Verifica se todos os processos terminaram a execução.
   - `printState`: Imprime o estado atual de todos os processos num determinado momento.
   - `initializeProcesses`: Inicia os processos com os dados fornecidos.
   - `changeProcessToSWP`: Altera o estado dos processos com base no ID do processo em execução e no ID do processo que causou a troca de contexto.
   - `canFitInMemory`: Verifica se o processo pode caber na memória.
   - `find_frame_to_replace_fifo`: Encontra um frame para substituir utilizando o FIFO.
   - `replace_frame`: Substitui um frame na memória.
   - `swapInProcess`: Troca um processo para a memória.

5. **Função Principal `main`:**
   - Solicita ao utilizador que escolha um input (00-04) para a simulação.
   - Com base na escolha do utilizador, seleciona os dados de entrada correspondentes e inicia os processos.
   - Inicia a fila de processos prontos.
   - Inicia a simulação do gestor de memória de processos num loop principal.
   - Em cada iteração do loop, atualiza o estado de cada processo com base nas instruções executadas.
   - Decide qual processo deve ser executado em seguida com base nas regras de escalonamento definidas.
   - Verifica se todos os processos terminaram e, se sim, encerra a simulação.

## Funcionamento do Algoritmo

1. **Inicialização:** O código solicita ao utilizador que escolha um input (00-04) para a simulação. Com base na escolha do utilizador, os dados de entrada correspondentes são carregados e os processos são iniciados com esses dados.

2. **Simulação do Gerenciamento de Memória:** A simulação é realizada num loop principal. Em cada iteração do loop, o estado de cada processo é atualizado com base nas instruções executadas. O algoritmo decide qual processo deve ser executado a seguir, com base nas regras definidas.

3. **Encerramento da Simulação:** A simulação continua até que todos os processos tenham terminado a execução. Quando todos os processos terminam, a simulação é encerrada.

## Saída do Programa

A saída do programa é uma tabela que mostra o estado de cada processo em cada momento de tempo durante a simulação. Os estados possíveis são: `NOTHING` (nenhum), `READY` (pronto para execução), `SW_RDY` (pronto para swap), `EXECUTING` (em execução), `INTERRUPTIBLE` (pode ser interrompido), `SW_INT` (interrompido durante swap), `ZOMBIE` (terminado, mas ainda não removido do sistema).

Cada linha da tabela representa um momento de tempo e cada coluna representa um processo. Os estados dos processos são impressos na tabela de acordo com o estado atual de cada processo num determinado momento.