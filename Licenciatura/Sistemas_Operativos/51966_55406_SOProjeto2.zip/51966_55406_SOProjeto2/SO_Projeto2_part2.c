#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "queue.c"
#include "inputs_part2.c"

// Constantes
#define NUM_INSTRUCTIONS 11
#define QUANTUM 3
#define MEMORY_SIZE 20
#define PAGE_SIZE 2

// Define o número de frames na memória
#define NUM_FRAMES (MEMORY_SIZE / PAGE_SIZE)

// Estados
typedef enum
{
    NOTHING,
    READY,
    SW_RDY,
    EXECUTING,
    INTERRUPTIBLE,
    SW_INT,
    ZOMBIE
} State;

// Estrutura que representa um processo
typedef struct
{
    int instructions[NUM_INSTRUCTIONS];
    int current_instruction;
    int id;
    State state;
    int zombie_count;
    int pages_in_memory;
} Process;

// Estrutura que representa um frame da memória
typedef struct
{
    int process_id;  // ID do processo que está a usar a frame
    int page_number; // Número da página do processo que está a usar a frame
} Frame;

Process AllProcesses[10]; // Array de todos os processos
int num_programs = 0;     // Número de programas
int num_processes = 0;    // Número de processos
Queue ready;              // Fila de processos prontos
Frame memory[NUM_FRAMES]; // Array de frames na memória

// Variáveis auxiliares para dados de entrada
int *inputP2Mem;
int (*inputP2Exec)[NUM_INSTRUCTIONS];
int inputP2MemSize;
int inputP2ExecSize;

// Função que verifica se todos os processos terminaram
bool checkIsFinished()
{
    for (int i = 0; i < num_programs; i++)
    {
        if (AllProcesses[i].zombie_count < 2)
        {
            return false;
        }
    }
    return true;
}

// Função que imprime o estado atual dos processos
void printState(int time)
{
    printf("%-10d", time);

    for (int j = 0; j < num_programs; j++)
    {
        Process p = AllProcesses[j];
        char state_str[20];
        char frames_str[50];
        char combined_str[70];

        // Verifica o estado do processo e imprime o estado correspondente
        if (AllProcesses[j].state == EXECUTING)
        {
            snprintf(state_str, sizeof(state_str), "|EXECUTING");
        }
        else if (AllProcesses[j].state == INTERRUPTIBLE)
        {
            snprintf(state_str, sizeof(state_str), "|INTERRUPTIBLE");
        }
        else if (AllProcesses[j].state == ZOMBIE && AllProcesses[j].zombie_count < 2)
        {
            snprintf(state_str, sizeof(state_str), "|ZOMBIE");
        }
        else if (AllProcesses[j].state == READY)
        {
            snprintf(state_str, sizeof(state_str), "|READY");
        }
        else if (AllProcesses[j].state == SW_RDY)
        {
            snprintf(state_str, sizeof(state_str), "|SW_RDY");
        }
        else if (AllProcesses[j].state == SW_INT)
        {
            snprintf(state_str, sizeof(state_str), "|SW-INT");
        }
        else
        {
            snprintf(state_str, sizeof(state_str), "|");
        }

        // Determina a string dos frames do processo
        if (p.pages_in_memory == 0)
        {
            snprintf(frames_str, sizeof(frames_str), " ");
        }
        else
        {
            if (p.state == ZOMBIE && p.zombie_count >= 2 || p.state == NOTHING)
            {
                snprintf(frames_str, sizeof(frames_str), " ");
            }
            else
            {
                char temp_str[5];
                snprintf(frames_str, sizeof(frames_str), " (");
                int aux_printer = 0;
                for (int k = 0; k < NUM_FRAMES; k++)
                {
                    Frame f = memory[k];
                    if (f.process_id == p.id)
                    {
                        snprintf(temp_str, sizeof(temp_str), "F%d", k);
                        strcat(frames_str, temp_str);
                        if (aux_printer < p.pages_in_memory - 1)
                        {
                            strcat(frames_str, ",");
                        }
                        aux_printer++;
                    }
                }
                strcat(frames_str, ")");
            }
        }

        // Combina as strings de estado e frames
        snprintf(combined_str, sizeof(combined_str), "%-14s %-25s", state_str, frames_str);

        // Imprime a string combinada
        printf("%-39s", combined_str);
    }

    printf("\n");
}

// Função que altera o estado dos processos com base no ID do processo em execução e no ID do processo que causou a troca de contexto
void changeProcessToSWP(int ProcessId, int ProcessInExecution)
{
    for (int j = 0; j < num_programs; j++)
    {
        // Obtém o processo atual
        Process p = AllProcesses[j];

        // Se o ID do processo atual for diferente do ID do processo que causou a troca de contexto
        if (p.id != ProcessId)
        {
            // Se o processo não estiver no estado NOTHING ou ZOMBIE
            if (p.state != NOTHING && p.state != ZOMBIE)
            {
                if (checkIfElementIsInQueue(j, ready))
                {
                    // Altera o estado do processo para SW_RDY (pronto para swap)
                    p.state = SW_RDY;
                }
                else
                {
                    // Altera o estado para SW_RDY
                    p.state = SW_RDY;
                    enqueue(j, ready);
                }
            }
        }
        else
        {
            // Se o processo atual é o mesmo que causou a troca de contexto, exceto o processo em execução
            if (j != ProcessInExecution)
            {
                // Se o processo não estiver no estado NOTHING, ZOMBIE ou INTERRUPTIBLE
                if (p.state != NOTHING && p.state != ZOMBIE && p.state != INTERRUPTIBLE)
                {
                    // Altera o estado do processo para READY
                    p.state = READY;
                }
            }
        }
        // Atualiza o processo na lista de todos os processos
        AllProcesses[j] = p;
    }
}

// Função que inicializa os processos
void initializeProcesses(int input[][NUM_INSTRUCTIONS], int num_programs)
{
    // Itera sobre todos os programas a serem iniciados
    for (int i = 0; i < num_programs; i++)
    {
        // Declaração da variável p do tipo Process
        Process p;

        // Define o ID do processo com o valor da primeira instrução do input
        p.id = input[i][0];

        // Define a instrução atual como a primeira instrução do processo
        p.current_instruction = 1;

        // Define o estado inicial do processo como NOTHING
        p.state = NOTHING;

        // Inicia o contador de processos zombie como 0
        p.zombie_count = 0;

        // Inicia o número de páginas na memória como 0
        p.pages_in_memory = 0;

        // Itera sobre todas as instruções do processo
        for (int j = 0; j < NUM_INSTRUCTIONS; j++)
        {
            // Copia as instruções do input para o array de instruções do processo
            p.instructions[j] = input[i][j];
        }

        // Armazena o processo iniciado no array global de todos os processos
        AllProcesses[i] = p;
    }
}

// Função que verifica se o processo pode caber na memória
bool canFitInMemory(int process_memory)
{
    int total_memory = 0;
    bool alreadyAdded[num_processes];

    // Inicia o array de controle alreadyAdded como false
    for (int i = 0; i < num_processes; i++)
    {
        alreadyAdded[i] = false;
    }

    // Itera sobre todos os processos
    for (int i = 0; i < num_programs; i++)
    {
        if (AllProcesses[i].state != ZOMBIE && !alreadyAdded[AllProcesses[i].id - 1])
        {
            // Soma a memória usada por processos não zombies
            total_memory += AllProcesses[i].pages_in_memory * PAGE_SIZE;

            // Marca o processo como adicionado ao total de memória
            alreadyAdded[AllProcesses[i].id - 1] = true;
        }
    }

    // Verifica se adicionar a memória do novo processo não excede o limite de memória
    return (total_memory + process_memory) <= MEMORY_SIZE;
}

int find_frame_to_replace_fifo()
{
    // Variável estática que mantém o índice do próximo frame a ser substituído
    static int next_frame_to_replace = 0;

    // Armazena o índice do frame atual a ser substituído
    int frame_index = next_frame_to_replace;

    // Atualiza o índice para o próximo frame a ser substituído
    next_frame_to_replace = (next_frame_to_replace + 1) % NUM_FRAMES;

    // Retorna o índice do frame a ser substituído
    return frame_index;
}

void replace_frame(int frame_index, int process_id, int page_number)
{
    // Se o frame já estiver ocupado por algum processo
    if (memory[frame_index].process_id != 0)
    {
        for (int i = 0; i < num_programs; i++)
        {
            // Se o ID do processo corresponder ao ID do processo que ocupa o frame atual
            if (AllProcesses[i].id == memory[frame_index].process_id)
            {
                // Decrementa o contador de páginas na memória para o processo que está a ser substituído
                AllProcesses[i].pages_in_memory--;
            }
        }
    }

    // Atualiza o frame na memória com o novo processo e o número da página
    memory[frame_index].process_id = process_id;
    memory[frame_index].page_number = page_number;
}

// Função que troca um processo para a memória
void swapInProcess(int process_index)
{
    // Obtém o processo da lista de todos os processos
    Process p = AllProcesses[process_index];

    // Calcula o número de páginas necessárias para o processo
    int requiredPages = (inputP2Mem[p.id - 1] + PAGE_SIZE - 1) / PAGE_SIZE;

    // Verifica se o número de páginas necessárias já está alocado
    if (requiredPages == p.pages_in_memory)
    {
        return; // Todas as páginas necessárias já estão alocadas, então não faz nada
    }
    else
    {
        // Loop para cada página necessária
        for (int page_number = 0; page_number < requiredPages; page_number++)
        {
            // Encontra um frame para substituir
            int frame_index = find_frame_to_replace_fifo();

            // Substitui o frame encontrado com a nova página do processo
            replace_frame(frame_index, p.id, page_number);
        }
        // Atualiza o número de páginas na memória do processo
        p.pages_in_memory = requiredPages;

        // Atualiza o processo na lista de todos os processos
        AllProcesses[process_index] = p;

        // Atualiza o número de páginas na memória para o processo em todas as instâncias da lista de processos
        for (int i = 0; i < num_programs; i++)
        {
            if (AllProcesses[i].id == p.id)
            {
                AllProcesses[i].pages_in_memory = p.pages_in_memory;
            }
        }
    }
}

// Função principal do programa
int main()
{
    int choice;
    printf("Escolha um input (00-04): ");
    scanf("%d", &choice); // Lê a escolha do utilizador

    // Seleciona o conjunto de dados de entrada com base na escolha do utilizador
    switch (choice)
    {
    case 0:
        inputP2Mem = inputP2Mem00;
        inputP2Exec = inputP2Exec00;
        inputP2MemSize = sizeof(inputP2Mem00) / sizeof(inputP2Mem00[0]);
        inputP2ExecSize = sizeof(inputP2Exec00) / sizeof(inputP2Exec00[0]);
        num_processes = inputP2MemSize;
        num_programs = 3;
        break;
    case 1:
        inputP2Mem = inputP2Mem01;
        inputP2Exec = inputP2Exec01;
        inputP2MemSize = sizeof(inputP2Mem01) / sizeof(inputP2Mem01[0]);
        inputP2ExecSize = sizeof(inputP2Exec01) / sizeof(inputP2Exec01[0]);
        num_processes = inputP2MemSize;
        num_programs = 4;
        break;
    case 2:
        inputP2Mem = inputP2Mem02;
        inputP2Exec = inputP2Exec02;
        inputP2MemSize = sizeof(inputP2Mem02) / sizeof(inputP2Mem02[0]);
        inputP2ExecSize = sizeof(inputP2Exec02) / sizeof(inputP2Exec02[0]);
        num_processes = inputP2MemSize;
        num_programs = 5;
        break;
    case 3:
        inputP2Mem = inputP2Mem03;
        inputP2Exec = inputP2Exec03;
        inputP2MemSize = sizeof(inputP2Mem03) / sizeof(inputP2Mem03[0]);
        inputP2ExecSize = sizeof(inputP2Exec03) / sizeof(inputP2Exec03[0]);
        num_processes = inputP2MemSize;
        num_programs = 7;
        break;
    case 4:
        inputP2Mem = inputP2Mem04;
        inputP2Exec = inputP2Exec04;
        inputP2MemSize = sizeof(inputP2Mem04) / sizeof(inputP2Mem04[0]);
        inputP2ExecSize = sizeof(inputP2Exec04) / sizeof(inputP2Exec04[0]);
        num_processes = inputP2MemSize;
        num_programs = 10;
        break;
    default:
        printf("Escolha inválida.\n");
        exit(1);
    }

    // Inicia os processos com os dados de entrada selecionados
    initializeProcesses(inputP2Exec, num_programs);

    ready = inicializeQueue();
    int time = 1;
    int quantum = 0;
    int changeQuantum = 0;
    int ProcessInExecution = -1;
    int lastProcessInExecution = -1;
    int nextProcessInExecution = -1;

    // Imprime o cabeçalho da tabela de estados
    printf("%-10s", "time inst");
    for (int i = 0; i < num_programs; i++)
    {
        printf("|th%-37d", i + 1);
    }
    printf("\n");

    // Loop principal do simulador gestor de memória
    while (true)
    {
        for (int i = 0; i < num_programs; i++)
        {
            // Obtém o processo atual a partir do array global de processos
            Process p = AllProcesses[i];

            // Lida com o estado inicial do processo
            if (p.current_instruction == 1)
            {
                // Decrementa o contador de instruções da instrução atual
                p.instructions[p.current_instruction]--;

                // Verifica se a instrução atual foi concluída
                if (p.instructions[p.current_instruction] == 0)
                {
                    // Se há um processo em execução e o ID do processo atual é diferente do processo em execução
                    if (ProcessInExecution != -1 && p.id != AllProcesses[ProcessInExecution].id)
                    {
                        p.state = SW_RDY; // Define o estado como SW_RDY
                    }
                    else
                    {
                        p.state = READY; // Define o estado como READY
                    }
                    // Avança para a próxima instrução
                    p.current_instruction++; 

                    // Adiciona o processo à fila
                    enqueue(i, ready);       
                }
            }

            // Lida com processos no estado INTERRUPTIBLE
            if (p.state == INTERRUPTIBLE)
            {
                // Verifica se a instrução atual foi concluída
                if (p.instructions[p.current_instruction] == 0)
                {
                    // Avança para a próxima instrução
                    p.current_instruction++; 
                    p.state = READY;   

                    // Adiciona o processo à fila
                    enqueue(i, ready);       
                }
                else
                {
                    // Decrementa o contador de instruções da instrução atual
                    p.instructions[p.current_instruction]--;

                    // Verifica se a instrução atual foi concluída após o decremento
                    if (p.instructions[p.current_instruction] == 0)
                    {
                        // Avança para a próxima instrução
                        p.current_instruction++; 
                        p.state = READY; 

                         // Adiciona o processo à fila     
                        enqueue(i, ready);      
                    }
                }
            }

            // Incrementa o contador ZOMBIE para processos no estado de ZOMBIE
            if (p.state == ZOMBIE)
            {
                p.zombie_count++; // Incrementa o contador de estado ZOMBIE
            }

            // Lida com processos que estavam em estado de SW_INT (interrupção durante a troca)
            if (p.state == SW_INT)
            {
                p.state = SW_RDY;  // Define o estado como SW_RDY
                enqueue(i, ready); // Adiciona o processo à fila de prontos
            }

            // Atualiza o processo no array global de processos
            AllProcesses[i] = p;
        }

        // Seleciona um processo para execução se não houver nenhum em execução
        if (ProcessInExecution == -1)
        {
            if (!isEmpty(ready))
            {
                // Obtemos o próximo processo da fila
                nextProcessInExecution = dequeue(ready);

                // Verifica se houve mudança de processo em execução
                if (lastProcessInExecution != -1 && AllProcesses[nextProcessInExecution].id != AllProcesses[lastProcessInExecution].id)
                {
                    changeQuantum = 1;                           // Indica que houve mudança de processo para ajustar o quantum
                    ProcessInExecution = nextProcessInExecution; // Define o próximo processo em execução
                }
                else
                {
                    ProcessInExecution = nextProcessInExecution; // Define o próximo processo em execução

                    // Limpa a variável que armazena o próximo processo em execução
                    nextProcessInExecution = -1;

                    // Atualiza o último processo em execução
                    lastProcessInExecution = ProcessInExecution;

                    // Obtém o processo atual da lista de todos os processos
                    Process p = AllProcesses[ProcessInExecution];

                    // Define o estado do processo como EXECUTING
                    p.state = EXECUTING;

                    // Define o quantum restante para o processo em execução
                    quantum = QUANTUM - 1;

                    // Decrementa o contador de instruções do processo
                    p.instructions[p.current_instruction]--;

                    // Atualiza o processo na lista de todos os processos
                    AllProcesses[ProcessInExecution] = p;

                    // Troca o processo para a memória se necessário
                    swapInProcess(ProcessInExecution);

                    // Altera o estado do processo para SWP se necessário
                    changeProcessToSWP(AllProcesses[ProcessInExecution].id, ProcessInExecution);
                }
            }
        }

        else if (nextProcessInExecution != -1)
        {
            // Verifica se ocorreu uma mudança de quantum
            if (changeQuantum == 2)
            {
                // Define o próximo processo em execução
                ProcessInExecution = nextProcessInExecution;

                // Limpa a variável que armazena o próximo processo em execução
                nextProcessInExecution = -1;

                // Atualiza o último processo em execução
                lastProcessInExecution = ProcessInExecution;

                // Obtém o processo atual da lista de todos os processos
                Process p = AllProcesses[ProcessInExecution];

                // Define o estado do processo como EXECUTING
                p.state = EXECUTING;

                // Define o quantum restante para o processo em execução
                quantum = QUANTUM - 1;

                // Decrementa o contador de instruções do processo
                p.instructions[p.current_instruction]--;

                // Atualiza o processo na lista de todos os processos
                AllProcesses[ProcessInExecution] = p;

                // Troca o processo para a memória se necessário
                swapInProcess(ProcessInExecution);

                // Altera o estado do processo para SWP se necessário
                changeProcessToSWP(p.id, ProcessInExecution);
            }
            else
            {
                // Incrementa o contador de mudança de quantum
                changeQuantum++;
            }
        }

        else
        {
            Process p = AllProcesses[ProcessInExecution];

            // Verifica se a instrução atual do processo foi concluída
            if (p.instructions[p.current_instruction] <= 0)
            {
                // Verifica se é a última instrução ou se a próxima instrução é 0
                if (p.current_instruction == NUM_INSTRUCTIONS - 1 || p.instructions[p.current_instruction + 1] == 0)
                {
                    // Avança para a próxima instrução
                    p.current_instruction++;

                    // Define o estado como ZOMBIE
                    p.state = ZOMBIE;

                    AllProcesses[ProcessInExecution] = p;

                    // Define o processo em execução como -1
                    ProcessInExecution = -1;
                }
                else
                {
                    // Define o estado como INTERRUPTIBLE
                    p.state = INTERRUPTIBLE;

                    // Avança para a próxima instrução
                    p.current_instruction++;
                    AllProcesses[ProcessInExecution] = p;

                    // Define o processo em execução como -1
                    ProcessInExecution = -1;
                }
            }
            // Verifica se o quantum do processo em execução acabou
            else if (quantum == 0)
            {
                if (p.instructions[p.current_instruction] > 0)
                {
                    // Define o estado como READY
                    p.state = READY;
                    AllProcesses[ProcessInExecution] = p;

                    // Adiciona o processo na fila de prontos
                    enqueue(ProcessInExecution, ready);

                    // Define o processo em execução como -1
                    ProcessInExecution = -1;
                }
                else
                {
                    // Verifica se é a última instrução ou se a próxima instrução é 0
                    if (p.current_instruction == NUM_INSTRUCTIONS - 1 || p.instructions[p.current_instruction + 1] == 0)
                    {
                        // Avança para a próxima instrução
                        p.current_instruction++;

                        // Define o estado como ZOMBIE
                        p.state = ZOMBIE;
                        AllProcesses[ProcessInExecution] = p;

                        // Define o processo em execução como -1
                        ProcessInExecution = -1;
                    }
                    else
                    {
                        // Define o estado como INTERRUPTIBLE
                        p.state = INTERRUPTIBLE;

                        // Avança para a próxima instrução
                        p.current_instruction++;
                        AllProcesses[ProcessInExecution] = p;

                        // Define o processo em execução como -1
                        ProcessInExecution = -1;
                    }
                }
                // Decrementa o contador de instruções do processo
                p.instructions[p.current_instruction]--;
                AllProcesses[ProcessInExecution] = p;
            }
            else
            {
                quantum--;

                // Decrementa o contador de instruções do processo
                p.instructions[p.current_instruction]--;
                AllProcesses[ProcessInExecution] = p;
            }
        }

        // Verifica se todos os processos terminaram
        if (checkIsFinished())
        {
            break;
        }
        // Imprime o estado atual dos processos
        printState(time);
        time++;
    }

    return 0;
}