# Simulador de Escalonamento de Processos

Este é um simulador de escalonamento de processos desenvolvido em C. O código implementa um algoritmo de escalonamento básico e simula o comportamento de vários processos concorrentes num sistema.

## Estrutura do Código



1. **Bibliotecas e Definições de Constantes:** O código inclui as bibliotecas padrão necessárias e define algumas constantes importantes, como o número máximo de instruções de um processo (NUM_INSTRUCTIONS) e o quantum de tempo (QUANTUM).

2. **Definição de Tipos e Estruturas de Dados** O código define um tipo enumerado State para representar os diferentes estados de um processo (READY, EXECUTING, INTERRUPTIBLE, ZOMBIE). Além disso, define uma estrutura Process para representar um processo, que contém informações como as instruções, o estado atual e o contador de processos “zombies”.

3. **Variáveis Globais:** O código declara variáveis globais para armazenar todos os processos (AllProcesses), o número total de programas (num_programs) e uma fila de processos prontos (`ready`). 

4. **Funções Auxiliares**:
   - `checkIsFinished`: Verifica se todos os processos terminaram a execução.
   - `printState`: Imprime o estado atual de todos os processos num determinado momento.
   - `initializeProcesses`: Inicializa os processos com os dados fornecidos.

5. **Função Principal `main`**:
   - Solicita ao utlizador que escolha um input (00-04) para a simulação.
   - Com base na escolha do utilizador, seleciona os dados de entrada correspondentes e inicializa os processos.
   - Inicializa a fila de processos prontos.
   - Inicia a simulação do escalonamento de processos num loop principal.
   - Em cada iteração do loop, atualiza o estado de cada processo com base nas instruções executadas.
   - Decide qual processo deve ser executado em seguida com base nas regras de escalonamento definidas.
   - Verifica se todos os processos terminaram e, se sim, encerra a simulação.

## Funcionamento do Algoritmo

1. **Inicialização**: O código solicita ao utilizador que escolha um input (00-04) para a simulação. Com base na escolha do utilizador, os dados de entrada correspondentes são carregados e os processos são inicializados com esses dados.

2. **Simulação do Escalonamento**: A simulação do escalonamento de processos é realizada num loop principal. Em cada iteração do loop, o estado de cada processo é atualizado com base nas instruções executadas. O escalonamento decide qual processo deve ser executado a seguir, com base nas regras de escalonamento definidas.

3. **Encerramento da Simulação**: A simulação continua até que todos os processos tenham terminado a execução. Quando todos os processos terminam, a simulação é encerrada.

## Saída do Programa

A saída do programa é uma tabela que mostra o estado de cada processo em cada momento de tempo durante a simulação. Os estados possíveis são: READY (pronto para execução), EXECUTING (em execução), INTERRUPTIBLE (pode ser interrompido), ZOMBIE (terminado, mas ainda não removido do sistema).

Cada linha da tabela representa um momento de tempo e cada coluna representa um processo. Os estados dos processos são impressos na tabela de acordo com o estado atual de cada processo num determinado momento.