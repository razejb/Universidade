#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "queue.c"  // Inclui o arquivo de implementação da fila
#include "inputs.h" // Inclui o arquivo de definição dos inputs

#define NUM_INSTRUCTIONS 11 // Define o número total de instruções
#define QUANTUM 3           // Define o valor do quantum

// Definição do estado de um processo
typedef enum
{
    NOTHING,
    READY,
    EXECUTING,
    INTERRUPTIBLE,
    ZOMBIE
} State;

// Estrutura de um processo
typedef struct
{
    int instructions[NUM_INSTRUCTIONS]; // Array de instruções
    int current_instruction;            // Índice da instrução atual
    int id;                             // Identificador do processo
    State state;                        // Estado do processo
    int zombie_count;                   // Contador de vezes que o processo ficou em estado ZOMBIE
} Process;

// Array que armazena todos os processos
Process AllProcesses[10];
int num_programs; // Número total de programas

Queue ready; // Fila de processos prontos

// Função para verificar se todos os processos terminaram
bool checkIsFinished()
{
    for (int i = 0; i < num_programs; i++)
    {
        // Verifica se o estado do processo não é ZOMBIE ou se o contador de ZOMBIE é inferior a 2
        if (/*AllProcesses[i].state != ZOMBIE ||*/ AllProcesses[i].zombie_count < 2)
        {
            return false; // Retorna falso se um dos processos ainda estiver em execução
        }
    }
    return true; // Retorna verdadeiro se todos os processos tiverem terminado
}

// Função para imprimir o estado dos processos em um determinado momento
void printState(int time)
{
    printf("   %3d          ", time); // Imprime o tempo atual

    // Loop para imprimir o estado de cada processo
    for (int j = 0; j < num_programs; j++)
    {
        // Verifica o estado do processo e imprime o estado correspondente
        if (AllProcesses[j].state == EXECUTING)
        {
            printf("EXECUTING       ");
        }
        else if (AllProcesses[j].state == INTERRUPTIBLE)
        {
            printf("INTERRUPTIBLE   ");
        }
        else if (AllProcesses[j].state == ZOMBIE && AllProcesses[j].zombie_count < 2)
        {
            printf("ZOMBIE          ");
        }
        else if (AllProcesses[j].state == READY)
        {
            printf("READY           ");
        }
        else
        {
            printf("                ");
        }
    }
    printf("\n"); // Imprime uma nova linha no final da linha de estados
}

// Função para inicializar os processos com os dados fornecidos
void initializeProcesses(int input[][NUM_INSTRUCTIONS], int num_programs)
{
    for (int i = 0; i < num_programs; i++)
    {
        Process p;                 // Cria uma nova instância de processo
        p.id = input[i][0];        // Define o identificador do processo
        p.current_instruction = 1; // Define a instrução atual como a primeira
        p.state = NOTHING;         // Define o estado inicial como NOTHING
        p.zombie_count = 0;        // Inicializa o contador de ZOMBIE como 0
        // Copia as instruções do input para o processo
        for (int j = 0; j < NUM_INSTRUCTIONS; j++)
        {
            p.instructions[j] = input[i][j];
        }
        AllProcesses[i] = p;         // Adiciona o processo inicializado ao array de processos
        //num_programs = num_programs; 
    }
}
int main()
{
    int choice;                           // Declara uma variável para armazenar a escolha do usuário
    printf("Escolha um input (00-04): "); // Exibe uma mensagem solicitando a escolha do input
    scanf("%d", &choice);                 // Lê a escolha do usuário

    int(*chosen_input)[NUM_INSTRUCTIONS]; // Declara um ponteiro para um array de instruções

    // Seleciona o input com base na escolha do utilizador e obtém o número total de programas
    switch (choice)
    {
    case 0:
        chosen_input = input00;                              // Seleciona o input00
        num_programs = sizeof(input00) / sizeof(input00[0]); // Calcula o número total de programas no input00
        break;
    case 1:
        chosen_input = input01;                              // Seleciona o input01
        num_programs = sizeof(input01) / sizeof(input01[0]); // Calcula o número total de programas no input01
        break;
    case 2:
        chosen_input = input02;                              // Seleciona o input02
        num_programs = sizeof(input02) / sizeof(input02[0]); // Calcula o número total de programas no input02
        break;
    case 3:
        chosen_input = input03;                              // Seleciona o input03
        num_programs = sizeof(input03) / sizeof(input03[0]); // Calcula o número total de programas no input03
        break;
    case 4:
        chosen_input = input04;                              // Seleciona o input04
        num_programs = sizeof(input04) / sizeof(input04[0]); // Calcula o número total de programas no input04
        break;
    default:
        printf("Escolha inválida\n"); // Exibe uma mensagem de erro para escolhas inválidas
        return 1;                     // Retorna 1 para indicar um erro
    }

    initializeProcesses(chosen_input, num_programs); // Inicia os processos com os dados fornecidos

    ready = inicializeQueue();       // Inicia a fila de processos prontos
    int time = 1;                    // Inicializa o tempo como 1
    int quantum = 0;                 // Inicializa o quantum como 0
    int changeQuantum = 0;           // Inicializa a variável de mudança de quantum como 0
    int ProcessInExecution = -1;     // Inicializa o processo em execução como -1
    int lastProcessInExecution = -1; // Inicializa o último processo em execução como -1
    int nextProcessInExecution = -1; // Inicializa o próximo processo em execução como -1

    // Cabeçalho da tabela de estados dos processos
    //printf("    x"); // Imprime um caractere 'x' no início da linha
    /*for (int i = 0; i <= num_programs; i++)
    {
        printf("----------------"); // Imprime uma linha de separadores
    }*/
    //printf("-x\n"); // Imprime um caractere 'x' no final da linha

    printf("    ");          // Imprime espaços em branco
    printf("time inst "); // Imprime a coluna para tempo e instrução
    for (int i = 0; i < num_programs; i++)
    {
        printf("| th%d", i + 1);     // Imprime o número do processo
        printf("           "); // Imprime espaços em branco para alinhar as colunas
    }
    printf("\n"); // Imprime uma nova linha

    /*printf("    |"); // Imprime espaços em branco e um caractere '|'
    for (int i = 0; i <= num_programs; i++)
    {
        printf("----------------"); // Imprime uma linha de separadores
    }
    printf("-|"); // Imprime um caractere '|' no final da linha*/
    //puts("");     // Imprime uma nova linha

    // Loop principal do simulador de escalonamento de processos
    while (true)
    {
        // Loop para atualizar o estado de cada processo
        for (int i = 0; i < num_programs; i++)
        {
            Process p = AllProcesses[i]; // Obtém o processo atual da lista de processos

            // Atualiza o estado do processo com base na instrução atual
            if (p.current_instruction == 1)
            {
                p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                // Verifica se a instrução atual foi concluída
                if (p.instructions[p.current_instruction] == 0)
                {
                    p.current_instruction++; // Avança para a próxima instrução
                    p.state = READY;         // Define o estado como READY
                    enqueue(i, ready);       // Adiciona o processo na fila de prontos
                }
            }
            if (p.state == INTERRUPTIBLE)
            {
                if (p.instructions[p.current_instruction] == 0)
                {
                    p.current_instruction++; // Avança para a próxima instrução
                    p.state = READY;         // Define o estado como READY
                    enqueue(i, ready);       // Adiciona o processo na fila de prontos
                }
                else
                {
                    p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                    // Verifica se a instrução atual foi concluída
                    if (p.instructions[p.current_instruction] == 0)
                    {
                        p.current_instruction++; // Avança para a próxima instrução
                        p.state = READY;         // Define o estado como READY
                        enqueue(i, ready);       // Adiciona o processo na fila de prontos
                    }
                }
            }
            if (p.state == ZOMBIE)
            {
                p.zombie_count++; // Incrementa o contador de ZOMBIE do processo
            }

            AllProcesses[i] = p; // Atualiza o processo na lista de processos
        }

        // Verifica se há processo em execução e decide qual processo executará em seguida
        if (ProcessInExecution == -1)
        {
            if (!isEmpty(ready)) // Verifica se a fila de prontos não está vazia
            {
                nextProcessInExecution = dequeue(ready); // Retira o próximo processo da fila de prontos
                // Verifica se o último processo em execução é diferente do próximo processo
                if (lastProcessInExecution != -1 && AllProcesses[nextProcessInExecution].id != AllProcesses[lastProcessInExecution].id)
                {
                    changeQuantum = 1;                           // Define a mudança de quantum como 1
                    ProcessInExecution = nextProcessInExecution; // Define o próximo processo em execução
                }
                else
                {
                    ProcessInExecution = nextProcessInExecution; // Define o próximo processo em execução
                    nextProcessInExecution = -1;
                    lastProcessInExecution = ProcessInExecution; // Atualiza o último processo em execução
                    Process p = AllProcesses[ProcessInExecution];
                    p.state = EXECUTING; // Define o estado como EXECUTING
                    //AllProcesses[ProcessInExecution] = p;
                    quantum = QUANTUM - 1;                   // Define o quantum restante para o processo em execução
                    p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                    AllProcesses[ProcessInExecution] = p;
                }
            }
        }
        else if (nextProcessInExecution != -1)
        {
            // Verifica se ocorreu uma mudança de quantum
            if (changeQuantum == 2)
            {
                ProcessInExecution = nextProcessInExecution; // Define o próximo processo em execução
                nextProcessInExecution = -1;
                lastProcessInExecution = ProcessInExecution; // Atualiza o último processo em execução
                Process p = AllProcesses[ProcessInExecution];
                p.state = EXECUTING;                     // Define o estado como EXECUTING
                quantum = QUANTUM - 1;                   // Define o quantum restante para o processo em execução
                p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                AllProcesses[ProcessInExecution] = p;
            }
            else
            {
                changeQuantum++; // Incrementa a mudança de quantum
            }
        }
        else
        {
            Process p = AllProcesses[ProcessInExecution];
            // Verifica se a instrução atual do processo foi concluída
            if (p.instructions[p.current_instruction] <= 0)
            {
                // Verifica se é a última instrução ou se a próxima instrução é 0
                if (p.current_instruction == NUM_INSTRUCTIONS - 1 || p.instructions[p.current_instruction + 1] == 0)
                {
                    p.current_instruction++; // Avança para a próxima instrução
                    p.state = ZOMBIE;        // Define o estado como ZOMBIE
                    AllProcesses[ProcessInExecution] = p;
                    ProcessInExecution = -1; // Define o processo em execução como -1
                }
                else
                {
                    p.state = INTERRUPTIBLE; // Define o estado como INTERRUPTIBLE
                    p.current_instruction++; // Avança para a próxima instrução
                    AllProcesses[ProcessInExecution] = p;
                    ProcessInExecution = -1; // Define o processo em execução como -1
                }
            }
            else if (quantum == 0) // Verifica se o quantum do processo em execução acabou
            {
                if (p.instructions[p.current_instruction] > 0)
                {
                    p.state = READY; // Define o estado como READY
                    AllProcesses[ProcessInExecution] = p;
                    enqueue(ProcessInExecution, ready); // Adiciona o processo na fila de prontos
                    ProcessInExecution = -1;            // Define o processo em execução como -1
                }
                else
                {
                    // Verifica se é a última instrução ou se a próxima instrução é 0
                    if (p.current_instruction == NUM_INSTRUCTIONS - 1 || p.instructions[p.current_instruction + 1] == 0)
                    {
                        p.current_instruction++; // Avança para a próxima instrução
                        p.state = ZOMBIE;        // Define o estado como ZOMBIE
                        AllProcesses[ProcessInExecution] = p;
                        ProcessInExecution = -1; // Define o processo em execução como -1
                    }
                    else
                    {
                        p.state = INTERRUPTIBLE; // Define o estado como INTERRUPTIBLE
                        p.current_instruction++; // Avança para a próxima instrução
                        AllProcesses[ProcessInExecution] = p;
                        ProcessInExecution = -1; // Define o processo em execução como -1
                    }
                }
                p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                AllProcesses[ProcessInExecution] = p;
            }
            else
            {
                quantum--;                               // Decrementa o quantum
                p.instructions[p.current_instruction]--; // Decrementa o contador de instruções do processo
                AllProcesses[ProcessInExecution] = p;
            }
        }

        // Verifica se todos os processos terminaram
        if (checkIsFinished())
        {
            break; // Sai do loop se todos os processos terminaram
        }
        printState(time); // Imprime o estado atual dos processos
        time++;           // Incrementa o tempo
    }
    return 0; // Retorna 0 para indicar que o programa foi executado com sucesso
}
