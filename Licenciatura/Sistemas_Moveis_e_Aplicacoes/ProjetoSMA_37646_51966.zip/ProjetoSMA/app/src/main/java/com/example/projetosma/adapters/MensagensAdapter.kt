package com.example.projetosma.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.projetosma.databinding.ItemMensagensEmissorBinding
import com.example.projetosma.databinding.ItemMensagensRecetorBinding
import com.example.projetosma.model.Mensagem
import com.example.projetosma.utils.Constantes
import com.google.firebase.auth.FirebaseAuth

class MensagensAdapter : Adapter<ViewHolder>() {

    // Lista de mensagens
    private var listaMensagens = emptyList<Mensagem>()

    // Adiciona uma nova lista de mensagens e notifica o adapter para atualizar a RecyclerView
    fun adicionarLista(lista: List<Mensagem>) {
        listaMensagens = lista
        notifyDataSetChanged()
    }

    // ViewHolder para mensagens do emissor
    class MensagensEmissorViewHolder(
        private val binding: ItemMensagensEmissorBinding
    ) : ViewHolder(binding.root) {

        // Liga os dados da mensagem às views
        fun bind(mensagem: Mensagem) {
            binding.textMensagemEmissor.text = mensagem.mensagem
        }

        companion object {
            // Infla o layout para o ViewHolder do emissor
            fun inflarLayout(parent: ViewGroup): MensagensEmissorViewHolder {
                val inflater = LayoutInflater.from(parent.context)
                val itemView = ItemMensagensEmissorBinding.inflate(
                    inflater, parent, false
                )
                return MensagensEmissorViewHolder(itemView)
            }
        }
    }

    // ViewHolder para mensagens do recetor
    class MensagensRecetorViewHolder(
        private val binding: ItemMensagensRecetorBinding
    ) : ViewHolder(binding.root) {

        // Liga os dados da mensagem às views
        fun bind(mensagem: Mensagem) {
            binding.textMensagemRecetor.text = mensagem.mensagem
        }

        companion object {
            // Infla o layout para o ViewHolder do recetor
            fun inflarLayout(parent: ViewGroup): MensagensRecetorViewHolder {
                val inflater = LayoutInflater.from(parent.context)
                val itemView = ItemMensagensRecetorBinding.inflate(
                    inflater, parent, false
                )
                return MensagensRecetorViewHolder(itemView)
            }
        }
    }

    // Retorna o tipo de view baseado no utilizador que enviou a mensagem
    override fun getItemViewType(position: Int): Int {
        val mensagem = listaMensagens[position]
        val idUtilizadorOnline = FirebaseAuth.getInstance().currentUser?.uid.toString()

        return if (idUtilizadorOnline == mensagem.idUtilizador) {
            Constantes.EMISSOR
        } else {
            Constantes.RECETOR
        }
    }

    // Cria um novo ViewHolder baseado no tipo de view
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return if (viewType == Constantes.EMISSOR) {
            MensagensEmissorViewHolder.inflarLayout(parent)
        } else {
            MensagensRecetorViewHolder.inflarLayout(parent)
        }
    }

    // Liga os dados da mensagem ao ViewHolder
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val mensagem = listaMensagens[position]
        when (holder) {
            is MensagensEmissorViewHolder -> holder.bind(mensagem)
            is MensagensRecetorViewHolder -> holder.bind(mensagem)
        }
    }

    // Retorna o número total de itens na lista de mensagens
    override fun getItemCount(): Int {
        return listaMensagens.size
    }
}
