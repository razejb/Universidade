package com.example.projetosma.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.MenuProvider
import com.example.projetosma.R
import com.example.projetosma.adapters.ViewPagerAdapter
import com.example.projetosma.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    // Inicia o binding, infla o layout da Main
    private val binding by lazy{
        ActivityMainBinding.inflate(layoutInflater)
    }

    // Inicia a instância do FirebaseAuth
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root) // Define o layout
        iniciarToolbar() // Chama o método para configurar a toolbar
        iniciarNavegacaoAbas() // Chama o método para configurar a navegação por abas
    }

    private fun iniciarNavegacaoAbas() {

        // Obtém as referências ao TabLayout e ao ViewPager do layout
        val tabLayout = binding.tabLayoutPrincipal
        val viewPager = binding.viewPagePrincipal

        // Configura o adapter para o ViewPager
        val abas = listOf("CHAT", "CONTACTOS")
        viewPager.adapter = ViewPagerAdapter(
            abas, supportFragmentManager, lifecycle
        )

        // Configura o indicador das abas para ocupar toda a largura
        tabLayout.isTabIndicatorFullWidth = true

        // Liga o TabLayout ao ViewPager
        TabLayoutMediator(tabLayout, viewPager){ aba, posicao ->
            aba.text = abas[posicao] // Define o texto das abas com base na posição
        }.attach()
    }

    private fun iniciarToolbar() {

        // Obtém a referência à toolbar do layout e a configura
        val toolbar = binding.includeMainToolbar.tbPrincipal
        setSupportActionBar(toolbar) // Define a toolbar como a ActionBar da atividade
        supportActionBar?.apply {
            title = "Easy Chat" // Define o título da ActionBar
            toolbar.setTitleTextColor(Color.parseColor("#FFDC57")) // Define a cor do texto da ActionBar
        }

        // Adiciona um MenuProvider para criar e gerenciar o menu da toolbar
        addMenuProvider(
            object : MenuProvider{
                override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                    menuInflater.inflate(R.menu.menu_principal, menu) // Infla o menu da toolbar
                }

                override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                    when(menuItem.itemId){
                        R.id.item_perfil -> {
                            startActivity(
                                Intent(applicationContext, PerfilActivity::class.java)
                            ) // Inicia a atividade PerfilActivity ao selecionar o item de perfil
                        }
                        R.id.item_sair -> {
                            sairUtilizador() // Chama o método para sair do usuário ao selecionar o item de sair
                        }
                    }
                    return true
                }
            }
        )
    }

    private fun sairUtilizador() {

        // Exibe um diálogo de confirmação para sair
        AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja realmente sair?")
            .setNegativeButton("Cancelar"){dialog, posicao -> }
            .setPositiveButton("Sim") { dialog, posicao ->
                firebaseAuth.signOut() // Faz logout do FirebaseAuth
                startActivity(
                    Intent(applicationContext, LoginActivity::class.java)
                ) // Inicia a atividade LoginActivity após o logout
            }
            .create()
            .show()
    }
}
