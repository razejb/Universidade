package com.example.projetosma.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.projetosma.databinding.ItemChatsBinding
import com.example.projetosma.model.Chat
import com.squareup.picasso.Picasso

class ChatAdapter(
    private val onClick: (Chat) -> Unit
) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    // Lista de chats
    private var listaChats = emptyList<Chat>()

    // Adiciona uma nova lista de chats e notifica o adapter para atualizar a RecyclerView
    fun adicionarLista(lista: List<Chat>) {
        listaChats = lista
        notifyDataSetChanged()
    }

    // ViewHolder interno que segura as views para cada item de chat
    inner class ChatViewHolder(
        private val binding: ItemChatsBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        // Liga os dados do chat às views
        fun bind(chat: Chat) {
            binding.textViewChatNome.text = chat.nome
            binding.textViewChatMensagem.text = chat.ultimaMensagem
            // Carrega a imagem do chat com o Picasso
            Picasso.get()
                .load(chat.foto)
                .into(binding.imageViewChatFoto)

            // Define um evento de clique para o item de chat
            binding.clItemChat.setOnClickListener {
                onClick(chat)
            }
        }
    }

    // Cria um novo ViewHolder quando não há views suficientes na RecyclerView
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = ItemChatsBinding.inflate(
            inflater, parent, false
        )
        return ChatViewHolder(itemView)
    }

    // Liga os dados do chat ao ViewHolder
    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val chat = listaChats[position]
        holder.bind(chat)
    }

    // Retorna o número total de itens na lista de chats
    override fun getItemCount(): Int {
        return listaChats.size
    }
}
