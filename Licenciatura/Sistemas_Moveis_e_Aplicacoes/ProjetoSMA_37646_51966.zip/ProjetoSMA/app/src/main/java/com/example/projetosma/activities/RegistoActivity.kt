package com.example.projetosma.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.projetosma.databinding.ActivityRegistoBinding
import com.example.projetosma.model.Utilizador
import com.example.projetosma.utils.exibirMensagem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestore

class RegistoActivity : AppCompatActivity() {

    // Inicia o binding de forma lazy
    private val binding by lazy {
        ActivityRegistoBinding.inflate(layoutInflater)
    }

    // Variáveis para armazenar os dados de registo
    private lateinit var nome: String
    private lateinit var email: String
    private lateinit var pass: String

    // Inicia instâncias do Firebase de forma lazy
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    private val firestore by lazy {
        FirebaseFirestore.getInstance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        iniciarToolbar() // Configura a toolbar
        iniciarEventosClique() // Configura os eventos de clique
    }

    private fun iniciarEventosClique() {
        binding.btnRegistar.setOnClickListener {
            if (validarCampos()) {
                // Se os campos são válidos, regista o utilizador
                registarUtilizador(nome, email, pass)
            }
        }
    }

    private fun registarUtilizador(nome: String, email: String, pass: String) {
        // Cria um utilizador com email e password no Firebase Auth
        firebaseAuth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener { resultado ->
                if (resultado.isSuccessful) {
                    // Guarda os dados do utilizador no Firestore
                    val idUtilizador = resultado.result.user?.uid
                    if (idUtilizador != null) {
                        val utilizador = Utilizador(idUtilizador, nome, email)
                        guardarUtilizadorFirestore(utilizador)
                    }
                }
            }.addOnFailureListener { erro ->
                // Trata os diferentes erros de registo
                try {
                    throw erro
                } catch (erroPassFraca: FirebaseAuthWeakPasswordException) {
                    erroPassFraca.printStackTrace()
                    exibirMensagem("Insira outra password, coloque letras maiúsculas, minúsculas e números!")
                } catch (erroUtilizadorExistente: FirebaseAuthUserCollisionException) {
                    erroUtilizadorExistente.printStackTrace()
                    exibirMensagem("Este email já pertence a outro utilizador!")
                } catch (erroCredenciaisInvalidas: FirebaseAuthInvalidCredentialsException) {
                    erroCredenciaisInvalidas.printStackTrace()
                    exibirMensagem("Email inválido, insira outro email!")
                }
            }
    }

    private fun guardarUtilizadorFirestore(utilizador: Utilizador) {
        // Guarda o utilizador no Firestore
        firestore.collection("utilizadores")
            .document(utilizador.id)
            .set(utilizador)
            .addOnSuccessListener {
                exibirMensagem("Já está registado!")
                // Inicia a MainActivity após o registo
                startActivity(Intent(applicationContext, MainActivity::class.java))
            }.addOnFailureListener {
                exibirMensagem("Erro no registo.")
            }
    }

    private fun validarCampos(): Boolean {
        // Valida os campos de registo
        nome = binding.EditNome.text.toString()
        email = binding.EditEmail.text.toString()
        pass = binding.EditPass.text.toString()

        return when {
            nome.isEmpty() -> {
                binding.textInputLayoutNome.error = "Insira o seu nome!"
                false
            }
            email.isEmpty() -> {
                binding.textInputLayoutEmail.error = "Insira o email!"
                false
            }
            pass.isEmpty() -> {
                binding.textInputLayoutPass.error = "Insira a password!"
                false
            }
            else -> {
                binding.textInputLayoutNome.error = null
                binding.textInputLayoutEmail.error = null
                binding.textInputLayoutPass.error = null
                true
            }
        }
    }

    private fun iniciarToolbar() {
        // Configura a toolbar como a ActionBar da atividade
        val toolbar = binding.includeToolbar.tbPrincipal
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            title = "Regista-te"
            setDisplayHomeAsUpEnabled(true) // Ativa o botão de voltar na toolbar
        }
    }
}
