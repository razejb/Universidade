package com.example.projetosma.activities

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projetosma.adapters.MensagensAdapter
import com.example.projetosma.databinding.ActivityMensagensBinding
import com.example.projetosma.model.Chat
import com.example.projetosma.model.Mensagem
import com.example.projetosma.model.Utilizador
import com.example.projetosma.utils.Constantes
import com.example.projetosma.utils.exibirMensagem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.squareup.picasso.Picasso

class MensagensActivity : AppCompatActivity() {

    // Inicia a instância do FirebaseAuth
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // Inicia a instância do FirebaseFirestore
    private val firestore by lazy {
        FirebaseFirestore.getInstance()
    }

    // Inicia o binding, inflan o layout da atividade
    private val binding by lazy{
        ActivityMensagensBinding.inflate(layoutInflater)
    }

    // Variável para guardar a referência ao ListenerRegistration do Firestore
    private lateinit var listenerRegistration: ListenerRegistration

    // Variáveis para armazenar os dados do recetor e do emissor
    private var dadosRecetor: Utilizador? = null
    private var dadosEmissor: Utilizador? = null

    // Variável para o adapter das mensagens
    private  lateinit var chatAdapter: MensagensAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root) // Define o layout da atividade
        recuperarDadosUtilizadores() // Recupera os dados dos utilizadores
        iniciarToolbar() // Configura a toolbar
        iniciarEventoClique() // Configura o evento de clique
        iniciarRecyclerView() // Inicia a RecyclerView
        iniciarListeners() // Inicia os listeners do Firestore
    }

    private fun iniciarRecyclerView() {
        with(binding){
            chatAdapter = MensagensAdapter() // Inicia o adapter das mensagens
            rvMensagens.adapter = chatAdapter // Define o adapter na RecyclerView
            rvMensagens.layoutManager = LinearLayoutManager(applicationContext) // Define o layout manager
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        listenerRegistration.remove() // Remove o listener do Firestore ao destruir a atividade
    }

    private fun iniciarListeners() {
        // Obtém os IDs do utilizador emissor e recetor
        val idUtilizadorEmissor = firebaseAuth.currentUser?.uid
        val idUtilizadorRecetor = dadosRecetor?.id
        if(idUtilizadorEmissor != null && idUtilizadorRecetor != null){
            // Adiciona um listener para a coleção de mensagens no Firestore
            listenerRegistration = firestore
                .collection(Constantes.MENSAGENS)
                .document(idUtilizadorEmissor)
                .collection(idUtilizadorRecetor)
                .orderBy("data", Query.Direction.ASCENDING)
                .addSnapshotListener { querySnapshot, erro ->
                    if(erro != null){
                        exibirMensagem("Erro na recuperação da mensagem") // Exibe mensagem de erro
                    }
                    val listaMensagens = mutableListOf<Mensagem>() // Lista para armazenar as mensagens
                    val documentos = querySnapshot?.documents
                    documentos?.forEach { documentSnapshot ->
                        val mensagem = documentSnapshot.toObject(Mensagem::class.java)
                        if(mensagem != null){
                            listaMensagens.add(mensagem) // Adiciona a mensagem à lista
                        }
                    }
                    // Verifica se a lista de mensagens não está vazia
                    if(listaMensagens.isNotEmpty()){
                        chatAdapter.adicionarLista(listaMensagens) // Adiciona as mensagens ao adapter
                    }
                }
        }
    }

    private fun iniciarEventoClique() {
        // Define o evento de clique para o botão de enviar mensagem
        binding.fabEnviar.setOnClickListener {
            val mensagem = binding.editMensagem.text.toString() // Obtém o texto da mensagem
            guardarMensagem(mensagem) // Guarda a mensagem no Firestore
        }
    }

    private fun guardarMensagem(textoMensagem: String) {
        if(textoMensagem.isNotEmpty()){
            val idUtilizadorEmissor = firebaseAuth.currentUser?.uid
            val idUtilizadorRecetor = dadosRecetor?.id
            if(idUtilizadorEmissor != null && idUtilizadorRecetor != null){
                val mensagem = Mensagem(idUtilizadorEmissor, textoMensagem) // Cria o objeto mensagem
                // Guarda a mensagem no Firestore para o emissor
                guardarMensagemFirestore(idUtilizadorEmissor, idUtilizadorRecetor, mensagem)
                val chatEmissor = Chat(
                    idUtilizadorEmissor, idUtilizadorRecetor,
                    dadosRecetor!!.foto, dadosRecetor!!.nome,
                    textoMensagem
                )
                guardarChatFirestore(chatEmissor) // Guarda o chat no Firestore para o emissor
                // Guarda a mesma mensagem no Firestore para o recetor
                guardarMensagemFirestore(idUtilizadorRecetor, idUtilizadorEmissor, mensagem)
                val chatRecetor = Chat(
                    idUtilizadorRecetor, idUtilizadorEmissor,
                    dadosEmissor!!.foto, dadosEmissor!!.nome,
                    textoMensagem
                )
                guardarChatFirestore(chatRecetor) // Guarda o chat no Firestore para o recetor
                binding.editMensagem.setText("") // Limpa o campo de texto da mensagem
            }
        }
    }

    private fun guardarChatFirestore(chat: Chat) {
        // Guarda o chat no Firestore
        firestore
            .collection(Constantes.CHAT)
            .document(chat.idUtilizadorEmissor)
            .collection(Constantes.ULTIMOS_CHATS)
            .document(chat.idUtilizadorRecetor)
            .set(chat)
            .addOnFailureListener {
                exibirMensagem("Erro ao guardar") // Exibe mensagem de erro
            }
    }

    private fun guardarMensagemFirestore(
        idUtilizadorEmissor: String,
        idUtilizadorRecetor: String,
        mensagem: Mensagem
    ) {
        // Guarda a mensagem no Firestore
        firestore
            .collection(Constantes.MENSAGENS)
            .document(idUtilizadorEmissor)
            .collection(idUtilizadorRecetor)
            .add(mensagem)
            .addOnFailureListener {
                exibirMensagem("Erro no envio da mensagem!") // Exibe mensagem de erro
            }
    }

    private fun iniciarToolbar() {
        val toolbar = binding.tbMensagens
        setSupportActionBar(toolbar) // Define a toolbar como a ActionBar da atividade
        supportActionBar?.apply {
            title = "" // Define o título da ActionBar como vazio
            if(dadosRecetor != null){
                binding.textViewNome.text = dadosRecetor!!.nome // Define o nome do recetor
                Picasso.get()
                    .load(dadosRecetor!!.foto)
                    .into(binding.imageViewFotoPerfil) // Carrega a foto do recetor
            }
            setDisplayHomeAsUpEnabled(true) // Ativa o botão de voltar
        }
    }

    private fun recuperarDadosUtilizadores() {
        // Dados do utilizador online
        val idUtilizadorEmissor = firebaseAuth.currentUser?.uid
        if(idUtilizadorEmissor != null){
            firestore
                .collection(Constantes.UTILIZADORES)
                .document(idUtilizadorEmissor)
                .get()
                .addOnSuccessListener { documentSnapshot ->
                    val utilizador = documentSnapshot.toObject(Utilizador::class.java)
                    if(utilizador != null){
                        dadosEmissor = utilizador // Armazena os dados do emissor
                    }
                }
        }
        // Recupera dados do recetor da mensagem
        val extras = intent.extras
        if(extras != null){
            dadosRecetor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                extras.getParcelable("DadosRecetor", Utilizador::class.java)
            } else {
                extras.getParcelable("DadosRecetor")
            }
        }
    }
}
