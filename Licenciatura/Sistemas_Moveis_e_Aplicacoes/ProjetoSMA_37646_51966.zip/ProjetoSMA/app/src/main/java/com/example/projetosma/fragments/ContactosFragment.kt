package com.example.projetosma.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projetosma.R
import com.example.projetosma.activities.MensagensActivity
import com.example.projetosma.adapters.ContactosAdapter
import com.example.projetosma.databinding.FragmentContactosBinding
import com.example.projetosma.model.Utilizador
import com.example.projetosma.utils.Constantes
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class ContactosFragment : Fragment() {

    // Inicia as variáveis para vinculação de layout, evento de snapshot e adapter de contactos
    private lateinit var binding: FragmentContactosBinding
    private lateinit var eventoSnapshot: ListenerRegistration
    private lateinit var contactosAdapter: ContactosAdapter

    // Inicia o FirebaseAuth de forma lazy
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // Inicia o FirebaseFirestore de forma lazy
    private val firestore by lazy {
        FirebaseFirestore.getInstance()
    }

    // Método chamado para criar a visualização do fragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Infla o layout do fragment usando data binding
        binding = FragmentContactosBinding.inflate(
            inflater, container, false
        )

        // Inicia o adapter de contactos com um callback para tratar o clique em um item de contacto
        contactosAdapter = ContactosAdapter { utilizador ->
            // Cria um intent para abrir a atividade de mensagens
            val intent = Intent(context, MensagensActivity::class.java)
            // Passa os dados do recetor para a atividade de mensagens
            intent.putExtra("DadosRecetor", utilizador)
            startActivity(intent)
        }

        // Configura o RecyclerView para usar o adapter de contactos
        binding.rvContactos.adapter = contactosAdapter
        // Configura o layout manager do RecyclerView como LinearLayoutManager
        binding.rvContactos.layoutManager = LinearLayoutManager(context)
        // Adiciona uma decoração de divisão entre os itens do RecyclerView
        binding.rvContactos.addItemDecoration(
            DividerItemDecoration(
                context, LinearLayoutManager.VERTICAL
            )
        )

        // Retorna o layout
        return binding.root
    }

    // Método chamado quando o fragment fica visível para o utilizador
    override fun onStart() {
        super.onStart()
        // Adiciona o listener para atualizações dos contactos
        adicionarListenerContactos()
    }

    // Método para adicionar um listener de atualizações dos contactos no Firestore
    private fun adicionarListenerContactos() {
        // Configura o listener de snapshot para a coleção de utilizadores
        eventoSnapshot = firestore
            .collection(Constantes.UTILIZADORES)
            .addSnapshotListener { querySnapshot, erro ->
                // Cria uma lista para armazenar os contactos recuperados
                val listaContactos = mutableListOf<Utilizador>()
                val documentos = querySnapshot?.documents

                // Itera sobre os documentos recuperados e converte-os para objetos Utilizador
                documentos?.forEach { documentSnapshot ->
                    val idUtilizadorOnline = firebaseAuth.currentUser?.uid
                    val utilizador = documentSnapshot.toObject(Utilizador::class.java)

                    // Adiciona o utilizador à lista de contactos se não for o utilizador online
                    if (utilizador != null && idUtilizadorOnline != null) {
                        if (idUtilizadorOnline != utilizador.id) {
                            listaContactos.add(utilizador)
                        }
                    }
                }
                // Atualiza o adapter de contactos com a nova lista de contactos
                if (listaContactos.isNotEmpty()) {
                    contactosAdapter.adicionarLista(listaContactos)
                }
            }
    }

    // Método chamado quando o fragmento é destruído
    override fun onDestroy() {
        super.onDestroy()
        // Remove o listener de snapshot do Firestore
        eventoSnapshot.remove()
    }
}
