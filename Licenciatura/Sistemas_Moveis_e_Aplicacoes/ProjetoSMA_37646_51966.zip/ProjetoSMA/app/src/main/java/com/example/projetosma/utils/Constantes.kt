package com.example.projetosma.utils

object Constantes {

    const val ORIGEM_CONTACTO = "origem_contacto"
    const val ORIGEM_CHAT = "origem_chat"

    const val MENSAGENS = "mensagens"
    const val UTILIZADORES = "utilizadores"
    const val CHAT = "chat"
    const val ULTIMOS_CHATS = "ultimos_chats"

    const val EMISSOR = 0
    const val RECETOR = 1
}