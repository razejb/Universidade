package com.example.projetosma.activities

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.projetosma.databinding.ActivityPerfilBinding
import com.example.projetosma.utils.exibirMensagem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso

class PerfilActivity : AppCompatActivity() {

    // Inicia o binding de forma lazy
    private val binding by lazy{
        ActivityPerfilBinding.inflate(layoutInflater)
    }

    // Variáveis para armazenar permissões
    private var permissaoCamera = false
    private var permissaoGaleria = false

    // Inicia instâncias do Firebase de forma lazy
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    private val storage by lazy {
        FirebaseStorage.getInstance()
    }

    private val firestore by lazy {
        FirebaseFirestore.getInstance()
    }

    // Gerir a seleção de conteúdo da galeria
    private val gerirGaleria = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ){uri ->
        if(uri != null){
            binding.imageViewPerfil.setImageURI(uri)
            uploadImageStorage(uri)
        }else{
            exibirMensagem("Nenhuma imagem selecionada")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        iniciarToolbar() // Inicia a toolbar
        solicitarPermissoes() // Solicita permissões
        iniciarEventosClique() // Inicia os eventos de clique

    }

    override fun onStart() {
        super.onStart()
        recuperarDadosIniciaisUtilizador() // Recupera os dados iniciais do utilizador
    }

    private fun recuperarDadosIniciaisUtilizador() {
        val idUtilizador = firebaseAuth.currentUser?.uid

        if(idUtilizador != null){
            firestore
                .collection("utilizadores")
                .document(idUtilizador)
                .get()
                .addOnSuccessListener { documentSnapshot ->

                    val dadosUtilizador = documentSnapshot.data
                    if(dadosUtilizador != null){

                        val nome = dadosUtilizador["nome"] as String
                        val foto = dadosUtilizador["foto"] as String

                        binding.editNomePerfil.setText(nome)
                        if(foto.isNotEmpty()){
                            Picasso.get()
                                .load(foto)
                                .into(binding.imageViewPerfil)
                        }
                    }
                }
        }
    }

    private fun uploadImageStorage(uri: Uri) {
        val idUtilizador = firebaseAuth.currentUser?.uid

        if(idUtilizador != null){
            storage
                .getReference("fotos")
                .child("utilizadores")
                .child(idUtilizador)
                .child("perfil.jpg")
                .putFile(uri)
                .addOnSuccessListener { task ->
                    exibirMensagem("Sucesso no upload da imagem")
                    task.metadata
                        ?.reference
                        ?.downloadUrl
                        ?.addOnSuccessListener { url ->

                            val dados = mapOf(
                                "foto" to url.toString()
                            )
                            updateDadosPerfil(idUtilizador, dados)
                        }
                }.addOnFailureListener {
                    exibirMensagem("Erro no upload da imagem")
                }
        }
    }

    private fun updateDadosPerfil(idUtilizador: String, dados: Map<String, String>) {
        firestore
            .collection("utilizadores")
            .document(idUtilizador)
            .update(dados)
            .addOnSuccessListener {
                exibirMensagem("Sucesso ao guardar perfil!")
            }
            .addOnFailureListener {
                exibirMensagem("Erro ao guardar perfil!")
            }
    }

    private fun iniciarEventosClique() {
        // Evento de clique para o botão de selecionar imagem
        binding.fabSelecionar.setOnClickListener {
            if(permissaoGaleria){
                gerirGaleria.launch("image/*")
            }else{
                exibirMensagem("Não tem permissão para acessar a galeria")
                solicitarPermissoes()
            }
        }

        // Evento de clique para o botão de guardar perfil
        binding.btnGuardarPerfil.setOnClickListener {
            val nomeUtilizador = binding.editNomePerfil.text.toString()
            if(nomeUtilizador.isNotEmpty()){
                val idUtilizador = firebaseAuth.currentUser?.uid
                if(idUtilizador != null){
                    val dados = mapOf(
                        "nome" to nomeUtilizador
                    )
                    updateDadosPerfil(idUtilizador, dados)
                }
            }else{
                exibirMensagem("Insira o nome para atualizar")
            }
        }
    }

    private fun solicitarPermissoes() {
        // Verifica se o utilizador tem permissão
        permissaoCamera = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        permissaoGaleria = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_MEDIA_IMAGES
        ) == PackageManager.PERMISSION_GRANTED

        // Lista de permissões a solicitar
        val blacklistPermissoes = mutableListOf<String>()

        if(!permissaoCamera)
            blacklistPermissoes.add(Manifest.permission.CAMERA)
        if(!permissaoGaleria)
            blacklistPermissoes.add(Manifest.permission.READ_MEDIA_IMAGES)

        if(blacklistPermissoes.isNotEmpty()){
            // Solicitar várias permissões
            val gerirPermissoes = registerForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ){ permissoes ->
                permissaoCamera = permissoes[Manifest.permission.CAMERA] ?: permissaoCamera
                permissaoGaleria = permissoes[Manifest.permission.READ_MEDIA_IMAGES] ?: permissaoGaleria
            }
            gerirPermissoes.launch(blacklistPermissoes.toTypedArray())
        }
    }

    private fun iniciarToolbar() {
        val toolbar = binding.includeToolbarPerfil.tbPrincipal
        setSupportActionBar(toolbar) // Configura a toolbar como a ActionBar da atividade
        supportActionBar?.apply {
            title = "Editar perfil"
            setDisplayHomeAsUpEnabled(true) // Ativa o botão de voltar na toolbar
        }
    }
}
