package com.example.projetosma.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projetosma.R
import com.example.projetosma.activities.MensagensActivity
import com.example.projetosma.adapters.ChatAdapter
import com.example.projetosma.databinding.FragmentChatBinding
import com.example.projetosma.model.Chat
import com.example.projetosma.model.Utilizador
import com.example.projetosma.utils.Constantes
import com.example.projetosma.utils.exibirMensagem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.toObject

class ChatFragment : Fragment() {

    // Inicia as variáveis para a vinculação de layout, evento de snapshot e adapter de chat
    private lateinit var binding: FragmentChatBinding
    private lateinit var eventoSnapshot: ListenerRegistration
    private lateinit var chatAdapter: ChatAdapter

    // Inicia o FirebaseAuth de forma lazy
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // Inicializa o FirebaseFirestore de forma lazy
    private val firestore by lazy {
        FirebaseFirestore.getInstance()
    }

    // Método chamado para criar a visualização do fragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Infla o layout do fragment com o data binding
        binding = FragmentChatBinding.inflate(
            inflater, container, false
        )

        // Inicia o adaptar de chat com um callback para tratar o clique em um item do chat
        chatAdapter = ChatAdapter { chat ->
            // Cria um intent para abrir a atividade de mensagens
            val intent = Intent(context, MensagensActivity::class.java)

            // Cria um objeto Utilizador a partir dos dados do chat
            val utilizador = Utilizador(
                id = chat.idUtilizadorRecetor,
                nome = chat.nome,
                foto = chat.foto
            )
            // Passa os dados do recetor para a atividade de mensagens
            intent.putExtra("DadosRecetor", utilizador)
            startActivity(intent)
        }

        // Configura o RecyclerView para usar o adapter de chat
        binding.rvChat.adapter = chatAdapter
        // Configura o layout manager do RecyclerView como LinearLayoutManager
        binding.rvChat.layoutManager = LinearLayoutManager(context)
        // Adiciona uma decoração de divisão entre os itens do RecyclerView
        binding.rvChat.addItemDecoration(
            DividerItemDecoration(
                context, LinearLayoutManager.VERTICAL
            )
        )

        // Retorna o layout
        return binding.root
    }

    // Método chamado quando o fragment fica visível para o utilizador
    override fun onStart() {
        super.onStart()
        // Adiciona o listener para atualizações do chat
        adicionarListenerChat()
    }

    // Método chamado quando o fragment é destruído
    override fun onDestroy() {
        super.onDestroy()
        // Remove o listener de snapshot do Firestore
        eventoSnapshot.remove()
    }

    // Método para adicionar um listener de atualizações do chat no Firestore
    private fun adicionarListenerChat() {
        // Obtém o ID do utilizador emissor
        val idUtilizadorEmissor = firebaseAuth.currentUser?.uid
        if (idUtilizadorEmissor != null) {
            // Configura o listener de snapshot para a coleção de últimos chats do utilizador
            eventoSnapshot = firestore
                .collection(Constantes.CHAT)
                .document(idUtilizadorEmissor)
                .collection(Constantes.ULTIMOS_CHATS)
                .orderBy("data", Query.Direction.DESCENDING)
                .addSnapshotListener { querySnapshot, erro ->
                    // Verifica se houve erro na recuperação dos dados
                    if (erro != null) {
                        activity?.exibirMensagem("Erro na recuperação da conversa")
                        return@addSnapshotListener
                    }

                    // Cria uma lista para armazenar os chats recuperados
                    val listaChats = mutableListOf<Chat>()
                    val documentos = querySnapshot?.documents

                    // Itera sobre os documentos recuperados e converte-os para objetos Chat
                    documentos?.forEach { documentSnapshot ->
                        val chat = documentSnapshot.toObject(Chat::class.java)
                        if (chat != null) {
                            listaChats.add(chat)
                        }
                    }
                    // Atualiza o adaptador de chat com a nova lista de chats
                    if (listaChats.isNotEmpty()) {
                        chatAdapter.adicionarLista(listaChats)
                    }
                }
        }
    }
}
