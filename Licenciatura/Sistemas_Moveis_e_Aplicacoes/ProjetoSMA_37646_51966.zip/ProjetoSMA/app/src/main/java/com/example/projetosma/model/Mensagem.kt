package com.example.projetosma.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class Mensagem(
    val idUtilizador: String = "",
    val mensagem: String = "",
    @ServerTimestamp
    val data: Date? = null,
)
