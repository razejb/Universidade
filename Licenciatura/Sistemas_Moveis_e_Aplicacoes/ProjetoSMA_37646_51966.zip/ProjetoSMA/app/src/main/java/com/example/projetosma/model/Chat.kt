package com.example.projetosma.model

import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class Chat(
    val idUtilizadorEmissor: String = "",
    val idUtilizadorRecetor: String = "",
    val foto: String = "",
    val nome: String = "",
    val ultimaMensagem: String = "",
    @ServerTimestamp
    val data: Date? = null

)
