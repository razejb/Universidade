package com.example.projetosma.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.projetosma.databinding.ActivityLoginBinding
import com.example.projetosma.utils.exibirMensagem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

// Classe LoginActivity que estende AppCompatActivity
class LoginActivity : AppCompatActivity() {

    // Propriedade binding iniciada
    private val binding by lazy{
        ActivityLoginBinding.inflate(layoutInflater)
    }

    // Variáveis para armazenar email e senha
    private lateinit var email: String
    private lateinit var pass: String

    // Instância do FirebaseAuth iniciada
    private val firebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    // Método chamado quando a atividade é criada
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Define o conteúdo da atividade como a raiz do layout vinculado
        setContentView(binding.root)
        // Inicia os eventos de clique
        iniciarEventosClique()
        // Desconecta o usuário atual do FirebaseAuth
        firebaseAuth.signOut()
    }

    // Método chamado quando a atividade está prestes a se tornar visível
    override fun onStart() {
        super.onStart()
        // Verifica se há um usuário logado
        verificarUtilizadorLogin()
    }

    // Verifica se há um usuário logado e inicia a MainActivity se houver
    private fun verificarUtilizadorLogin() {
        val utilizadorAtual = firebaseAuth.currentUser

        if(utilizadorAtual != null){
            startActivity(
                Intent(this, MainActivity::class.java)
            )
        }
    }

    // Configura os eventos de clique dos botões e textos
    private fun iniciarEventosClique() {
        binding.textRegisto.setOnClickListener{
            startActivity(
                Intent(this, RegistoActivity::class.java)
            )
        }

        binding.btnLogin.setOnClickListener{
            // Valida os campos antes de tentar login
            if(validarCampos()){
                loginUtilizador()
            }
        }
    }

    // Realiza o login do usuário utilizando FirebaseAuth
    private fun loginUtilizador() {
        firebaseAuth.signInWithEmailAndPassword(
            email, pass
        ).addOnSuccessListener {
            // Exibe mensagem de sucesso e inicia a MainActivity
            exibirMensagem("Login feito com sucesso!")
            startActivity(
                Intent(this, MainActivity::class.java)
            )
        }.addOnFailureListener { erro ->
            // Trata possíveis erros de login
            try {
                throw erro
            } catch (erroUtilizadorInvalido: FirebaseAuthInvalidUserException) {
                erroUtilizadorInvalido.printStackTrace()
                exibirMensagem("Este email não existe, regista-te!")
            } catch (erroCredenciaisInvalidas: FirebaseAuthInvalidCredentialsException) {
                erroCredenciaisInvalidas.printStackTrace()
                exibirMensagem("Email ou password incorretos!")
            }
        }
    }

    // Valida os campos de email e senha
    private fun validarCampos(): Boolean {
        email = binding.EditLoginEmail.text.toString()
        pass = binding.EditLoginPass.text.toString()

        // Verifica se o campo de email não está vazio
        if (email.isNotEmpty()) {
            binding.textInputLayoutLoginEmail.error = null

            // Verifica se o campo de senha não está vazio
            if (pass.isNotEmpty()) {
                binding.textInputLayoutLoginPass.error = null
                return true
            } else {
                // Exibe erro se o campo de senha estiver vazio
                binding.textInputLayoutLoginPass.error = "Insira a password!"
                return false
            }
        } else {
            // Exibe erro se o campo de email estiver vazio
            binding.textInputLayoutLoginEmail.error = "Insira o email!"
            return false
        }
    }

}
