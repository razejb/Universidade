package com.example.projetosma.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.projetosma.databinding.ItemContactosBinding
import com.example.projetosma.model.Utilizador
import com.squareup.picasso.Picasso

class ContactosAdapter(
    private val onClick: (Utilizador) -> Unit
) : Adapter<ContactosAdapter.ContactosViewHolder>() {

    // Lista de contactos
    private var listaContactos = emptyList<Utilizador>()

    // Adiciona uma nova lista de contactos e notifica o adapter para atualizar a RecyclerView
    fun adicionarLista(lista: List<Utilizador>) {
        listaContactos = lista
        notifyDataSetChanged()
    }

    // ViewHolder interno que segura as views para cada item de contacto
    inner class ContactosViewHolder(
        private val binding: ItemContactosBinding
    ) : ViewHolder(binding.root) {

        // Liga os dados do utilizador às views
        fun bind(utilizador: Utilizador) {
            binding.textViewContactoNome.text = utilizador.nome
            // Carrega a imagem do contacto com o Picasso
            Picasso.get()
                .load(utilizador.foto)
                .into(binding.imageViewContactoFoto)

            // Define um evento de clique para o item de contacto
            binding.clItemContacto.setOnClickListener {
                onClick(utilizador)
            }
        }
    }

    // Cria um novo ViewHolder quando não há views suficientes na RecyclerView
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactosViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = ItemContactosBinding.inflate(
            inflater, parent, false
        )
        return ContactosViewHolder(itemView)
    }

    // Liga os dados do utilizador ao ViewHolder
    override fun onBindViewHolder(holder: ContactosViewHolder, position: Int) {
        val utilizador = listaContactos[position]
        holder.bind(utilizador)
    }

    // Retorna o número total de itens na lista de contactos
    override fun getItemCount(): Int {
        return listaContactos.size
    }
}
