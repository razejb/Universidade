package com.example.projetosma.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.projetosma.fragments.ChatFragment
import com.example.projetosma.fragments.ContactosFragment

// Adapter para gerir a navegação entre diferentes fragments
class ViewPagerAdapter(

    private val abas: List<String>, // Lista de títulos das abas
    fragmentManager: FragmentManager,
    lifecycle: Lifecycle
) : FragmentStateAdapter(fragmentManager, lifecycle) {

    // Retorna o número de abas
    override fun getItemCount(): Int {
        return abas.size
    }

    // Cria e retorna o fragment correspondente à posição dada
    override fun createFragment(position: Int): Fragment {
        when (position) {
            // Retorna o fragment de Contactos na posição 1
            1 -> return ContactosFragment()
        }
        // Retorna o fragment de Chat para a posição 0
        return ChatFragment()
    }
}
