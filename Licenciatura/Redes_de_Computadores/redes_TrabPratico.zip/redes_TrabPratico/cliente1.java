import java.io.*;
import java.net.*;

public class cliente1 {

    private static final int PORT = 2001;
    private static final String IP = "alunos.di.uevora.pt";

    public static void main(String[] args) {

        try {
            Socket socket = new Socket(IP, PORT);
            System.out.println("Conected to the server...");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            String inputLine;
            String output;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.startsWith("PING")) {
                    output = inputLine.replaceFirst("PING", "PONG") + "\n";
                    out.write(output);
                    out.flush();
                }
                if (inputLine.equals("exit")) {
                    System.out.println("Client exited...");
                    break;
                }
            }

            socket.close();
        } catch (IOException e) {
            System.out.println("Failed to connect to the server...");
            e.printStackTrace();
        }
    }
}
