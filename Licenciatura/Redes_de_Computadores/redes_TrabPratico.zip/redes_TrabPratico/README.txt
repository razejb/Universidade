Trab redes

-----
* Parte I - Clientes

Nesta parte, deve implementar clientes de rede (TCP) que cumpram todo ou parte do protocolo de aplicação especificado em cada questão.

Embora os exercícios sejam separados, pretende-se implementar as funções incrementalmente, ou seja, o cliente da questão Y deve suportar todas as funcionalidades do programa da questão Y-1 (e assim recursivamente).
Serão classificados os programas que apenas implementem a funcionalidade da questão Y, mas não com a cotação total.

Todos os programas desenvolvidos nesta parte recebem 2 argumentos na linha de comando: o endereço e a porta do servidor.
É **obrigatório** respeitar o output pedido em cada pergunta.

Para cada alínea, o programa deve ser entregue com o nome "clienteY.X" em que Y é o número da questão e X a extensão usada (.c, .py, .java, etc).

1. Cliente "permanente"

Implemente um cliente de rede que, uma vez ligado ao servidor, mantenha essa ligação activa, através da resposta aos PINGs que o servidor envia periodicamente.

Assim, sempre que recebe a mensagem "PING XYZ\n" deve responder com "PONG XYZ\n", de forma a não perder a ligação.

Note que neste protocolo, todas as mensagens terminam com '\n'. Note também que este cliente não produz qualquer output para o ecrã (apenas responde aos PINGs de forma "silenciosa").

Pode testar o seu cliente usando o servidor em alunos.di.uevora.pt:2001

2. Cliente "observador"

O servidor envia mensagens da forma "ONLINE <user>\n" para assinalar a presença de <user> no servidor.
Implemente um cliente que, para cada mensagem destas recebida, imprime (no ecrã) uma string "<user> está online!\n".

Pode testar o seu cliente usando o servidor em alunos.di.uevora.pt:2002

3. Cliente "falador"

O servidor envia mensagens da forma "MSGFROM <user> <mensagem>\n" de cada vez que um <user> envia uma mensagem.

Implemente um cliente que, para cada mensagem destas recebida, imprime (no ecrã) uma string "<user> disse <mensagem>\n".

Pode testar o seu cliente usando o servidor em alunos.di.uevora.pt:2003

4. Cliente "downloadador"

O servidor envia ficheiros (de qualquer formato). O envio processa-se da seguinte forma:
  1. o servidor envia a mensagem "FILE <name> <size>\n";
  2. o cliente deve responder com "FILEREADY\n", para indicar que está preparado para receber o ficheiro;
  3. o servidor envia os <size> bytes do ficheiro e volta ao seu "trabalho" normal.

Implemente um cliente que receba o(s) ficheiro(s) que o servidor enviar e o(s) grave na pasta corrente.

Pode testar o seu cliente usando o servidor em alunos.di.uevora.pt:2004

5. Cliente "uploadador"

Implemente um cliente de rede que envia ficheiros para o servidor. O protocolo de aplicação define o processo de upload da seguinte forma:
  1. o cliente inicia o processo com a mensagem "UPLOAD <filename> <filesize>\n";
  2. caso esteja tudo bem, o servidor envia a mensagem "UPLOADREADY\n";
  3. o cliente deve então enviar os <filesize> bytes do ficheiro, preferencialmente em "batches" de não mais de 1024 bytes.

Pode testar o seu cliente usando o servidor em alunos.di.uevora.pt:2005

Nota: apesar de não fazer parte do protocolo de aplicação, o servidor de testes confirma a recepção do ficheiro com uma mensagem "Got <filesize> bytes.\n".

* Parte II - Servidores

Nesta parte, deve implementar servidores de rede que cumpram o protocolo especificado na questão correspondente. Não existem clientes de teste, mas pode usar os programas 'telnet' ou 'netcat' para testar os seus servidores.

Os servidores implementados devem admitir apenas um argumento na linha de comando: a porta TCP onde aceitam ligações.

1. Servidor "DNS"

Implemente um servidor TCP que materialize o seguinte protocolo:

  1. O cliente envia um pedido "IP <hostname>";
  2. O servidor resolve o DNS e envia a resposta "HOST <hostname> <ip>" ou "HOST <hostname> UNKNOWN".

2. Servidor "Subscribeador"

Implemente um servidor que aceita ligações TCP de clientes e não envia nada para estes, excepto quando:

  1. Se um cliente envia a mensagem "SUBSCRIBE\n", passa a receber a data e hora a cada 10 segundos;
  2. Se um cliente envia a mensagem "UNSUBSCRIBE\n", deixa de receber a data e hora a cada 10 segundos (mas a ligação fica activa)

Para a sintaxe da data e hora, pode usar a mesma que foi usada nas primeiras aulas práticas da disciplina.

3. Servidor "IoT"

O servidor escuta na porta 9000 (onde se ligam clientes "sensor") e na porta 9001 (onde se ligam clientes "atuador").
Um ou mais clientes ligam-se na porta 9000 e enviam os dados dos seus sensores na forma "<valor_int>\n" sempre que há dados novos.
Um ou mais clientes ligam-se na porta 9001 e ficam à espera de dados. Sempre que um cliente sensor envia dados, todos os clientes "atuador" ligados recebem a mensagem "SENSOR <id> <int>\n", de forma a que possam actuar sobre esses dados.

* Parte III - Bónus

Nesta parte, não obrigatória nem necessária, há mais dois exercícios que podem ser realizados para obter pontos bónus.

1. Servidor "Remote shell" TCP

O servidor recebe comandos do cliente e executa-os com a função ~popen()~. Devolve ao cliente o resultado da execução do comando.

2. Servidor "Remote shell" UDP

A mesma coisa que o anterior, mas em UDP



Código de Exemplo:

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {
        String out = runCmd("echo \"hello world\"");
        System.out.println(out);
    }

    public static String runCmd(String cmd) {
        StringBuilder output = new StringBuilder();

        Process p;
        try {
            p = Runtime.getRuntime().exec(cmd);
            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return output.toString();
    }
}


#+begin_src c
#include <stdio.h>
#include <stdlib.h>

char *runcmd(char *cmd) {
        FILE *fp;
        char path[1035];
        char *ret =
                        (char *)malloc(10000); /* max output size, for demo purposes.
                                                                          if it fills up, one should use realloc() */
        char *ptr = ret;           /* pointer to tmp */

        /* Open the command for reading. */
        fp = popen(cmd, "r");
        if (fp == NULL) {
                printf("Failed to run command\n");
                exit(1);
        }

        /* Read the output char by char and add it to the return string. */
        while (!feof(fp)) {
                *(ptr++) = fgetc(fp);
        }

        /* close */
        pclose(fp);

        return ret;
}

int main() {
        char *out = runcmd("echo \"hello world\"");

        printf("%s", out);
        free(out);

        return 0;
}
