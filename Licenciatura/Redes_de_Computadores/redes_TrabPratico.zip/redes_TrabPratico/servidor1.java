import java.io.*;
import java.net.*;

public class servidor1 {
    private static final int PORT = 9999;

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Socket successfully created...");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client accepted...");

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Do cliente: " + inputLine);
                if (inputLine.startsWith("IP ")) {
                    String hostname = inputLine.substring(3);
                    try {
                        InetAddress addr = InetAddress.getByName(hostname);
                        out.println("HOST " + hostname + " " + addr.getHostAddress());
                    } catch (UnknownHostException e) {
                        out.println("HOST " + hostname + " UNKNOWN");
                    }
                }

                if (inputLine.equalsIgnoreCase("exit")) {
                    System.out.println("Server exiting...");
                    System.exit(0);
                }
            }

            in.close();
            out.close();
            clientSocket.close();
            serverSocket.close();
        }
    }
}
