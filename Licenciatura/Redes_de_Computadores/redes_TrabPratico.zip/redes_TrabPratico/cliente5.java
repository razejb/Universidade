import java.io.*;
import java.net.*;

public class cliente5 {

    private static final int PORT = 2005; 
    private static final String IP = "alunos.di.uevora.pt";
    private static final String FILE_NAME = "test.png"; 

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(IP, PORT);
            System.out.println("Connected to the server...");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            File file = new File(FILE_NAME);
            int fileSize = (int) file.length();

            out.println("UPLOAD " + FILE_NAME + " " + fileSize);
            out.flush();

            String serverResponse = in.readLine();
            if (serverResponse.equals("UPLOADREADY")) {
                byte[] bytes = new byte[1024];
                InputStream fileInputStream = new FileInputStream(file);
                OutputStream socketOutputStream = socket.getOutputStream();

                int count;
                while ((count = fileInputStream.read(bytes)) > 0) {
                    socketOutputStream.write(bytes, 0, count);
                }

                fileInputStream.close();
                System.out.println("Ficheiro " + FILE_NAME + " enviado.");

             
                serverResponse = in.readLine();
                if (serverResponse.startsWith("Got ")) {
                    System.out.println("Server: " + serverResponse);
                }
            }

            socket.close();
            System.out.println("Connection with the server closed.");
        } catch (IOException e) {
            System.out.println("Failed to connect to the server...");
            e.printStackTrace();
        }
    }
}
