import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class servidor2 {
    private static final int PORT = 9999;
    private static Map<Socket, Timer> timers = new HashMap<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Socket successfully created...");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client accepted...");

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Do cliente: " + inputLine);
                if (inputLine.equals("SUBSCRIBE\\n")) {
                    Timer timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                            Date date = new Date();
                            out.println(dateFormat.format(date));
                        }
                    }, 0, 10000);
                    timers.put(clientSocket, timer);
                } else if (inputLine.equals("UNSUBSCRIBE\\n")) {
                    Timer timer = timers.get(clientSocket);
                    if (timer != null) {
                        timer.cancel();
                        timers.remove(clientSocket);
                    }
                } else if (inputLine.equalsIgnoreCase("exit")) {
                    System.out.println("SServer exiting...");
                    System.exit(0);
                }
            }

            in.close();
            out.close();
            clientSocket.close();
            serverSocket.close();
        }
    }
}
