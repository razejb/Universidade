import java.io.*;
import java.net.*;
import java.util.*;

public class servidor3 {
    private static final int SENSOR_PORT = 9000;
    private static final int ACTUATOR_PORT = 9001;
    private static Map<Socket, PrintWriter> actuators = new HashMap<>();

    public static void main(String[] args) throws IOException {
        new Thread(() -> startSensorServer()).start();
        new Thread(() -> startActuatorServer()).start();
    }

    public static void startSensorServer() {
        try (ServerSocket serverSocket = new ServerSocket(SENSOR_PORT)) {
            System.out.println("Servidor de sensor iniciado na porta " + SENSOR_PORT);
            while (true) {
                Socket sensorSocket = serverSocket.accept();
                new Thread(() -> handleSensor(sensorSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void startActuatorServer() {
        try (ServerSocket serverSocket = new ServerSocket(ACTUATOR_PORT)) {
            System.out.println("Servidor de atuador iniciado na porta " + ACTUATOR_PORT);
            while (true) {
                Socket actuatorSocket = serverSocket.accept();
                PrintWriter out = new PrintWriter(actuatorSocket.getOutputStream(), true);
                actuators.put(actuatorSocket, out);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void handleSensor(Socket sensorSocket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(sensorSocket.getInputStream()))) {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                for (PrintWriter out : actuators.values()) {
                    out.println("SENSOR " + sensorSocket.getRemoteSocketAddress() + " " + inputLine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            actuators.remove(sensorSocket);
        }
    }
}
