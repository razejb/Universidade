import java.io.*;
import java.net.*;

public class cliente3 {

    private static final int PORT = 2003; 
    private static final String IP = "alunos.di.uevora.pt";

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(IP, PORT);
            System.out.println("Connected to the server...");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.startsWith("MSGFROM")) {
                    String[] parts = inputLine.split(" ", 3);
                    String user = parts[1];
                    String message = parts[2];
                    System.out.println(user + " disse " + message);
                }
                if (inputLine.equals("exit")) {
                    System.out.println("Client exited...");
                    break;
                }
            }

            socket.close();
            System.out.println("Connection with the server closed.");
        } catch (IOException e) {
            System.out.println("Failed to connect to the server...");
            e.printStackTrace();
        }
    }
}
