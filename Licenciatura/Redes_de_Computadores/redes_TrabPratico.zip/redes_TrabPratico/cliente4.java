import java.io.*;
import java.net.*;

public class cliente4 {

    private static final int PORT = 2004; 
    private static final String IP = "alunos.di.uevora.pt";

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(IP, PORT);
            System.out.println("Connected to the server...");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.startsWith("FILE")) {
                    String[] parts = inputLine.split(" ", 3);
                    String fileName = parts[1];
                    int fileSize = Integer.parseInt(parts[2]);

                    out.println("FILEREADY\n");
                    out.flush();

                    byte[] bytes = new byte[1024];
                    InputStream is = socket.getInputStream();
                    FileOutputStream fos = new FileOutputStream(fileName);
                    BufferedOutputStream bos = new BufferedOutputStream(fos);

                    int count;
                    int totalBytesRead = 0;
                    while (totalBytesRead < fileSize) {
                        count = is.read(bytes);
                        totalBytesRead += count;
                        bos.write(bytes, 0, count);
                    }
                    bos.close();

                    System.out.println("Ficheiro " + fileName + " recebido.");
                }
                if (inputLine.equals("exit")) {
                    System.out.println("Client exited...");
                    break;
                }
            }

            socket.close();
            System.out.println("Connection with the server closed.");
        } catch (IOException e) {
            System.out.println("Failed to connect to the server...");
            e.printStackTrace();
        }
    }
}
