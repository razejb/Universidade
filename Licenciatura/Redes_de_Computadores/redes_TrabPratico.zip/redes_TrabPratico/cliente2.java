import java.io.*;
import java.net.*;

public class cliente2 {

    private static final int PORT = 2002;
    private static final String IP = "alunos.di.uevora.pt";

    public static void main(String[] args) {
       

        try {
        
            InetAddress serverAddress = InetAddress.getByName(IP);

            
            Socket socket = new Socket(serverAddress, PORT);

            
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            
            while (true) {
                String receivedMessage = reader.readLine();
                if (receivedMessage == null) break; 

                if (receivedMessage.startsWith("PING")) {
                    String response = "PONG" + receivedMessage.substring(4) + "\n";
                    writer.write(response);
                    writer.flush();
                }
               
                else if (receivedMessage.startsWith("ONLINE")) {
                    String user = receivedMessage.substring(7); 
                    System.out.println(user + " está online!");
                }
            }

            // Fechar o socket
            socket.close();
        } catch (UnknownHostException e) {
            System.err.println("Error resolving the host: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Failed to connect to the server..." + e.getMessage());
        }
    }
}
