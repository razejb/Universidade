import java.io.*;
import java.net.*;
import java.util.*;

public class RemoteShellServerTCP {
    private static final int REMOTE_SHELL_PORT = 9000;
    private static Map<Socket, PrintWriter> clients = new HashMap<>();

    public static void main(String[] args) throws IOException {
        new Thread(() -> startRemoteShellServer()).start();
    }

    public static void startRemoteShellServer() {
        try (ServerSocket serverSocket = new ServerSocket(REMOTE_SHELL_PORT)) {
            System.out.println("Servidor Remote Shell iniciado na porta " + REMOTE_SHELL_PORT);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void handleClient(Socket clientSocket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            clients.put(clientSocket, out);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                String commandOutput = runCmd(inputLine);
                out.println(commandOutput);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            clients.remove(clientSocket);
        }
    }

    public static String runCmd(String cmd) {
        StringBuilder output = new StringBuilder();

        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("bash", "-c", cmd);
        try {
            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return output.toString();
    }
}
