import java.io.*;
import java.net.*;

public class RemoteShellServerUDP {
    private static final int REMOTE_SHELL_PORT = 9000;

    public static void main(String[] args) throws IOException {
        try (DatagramSocket serverSocket = new DatagramSocket(REMOTE_SHELL_PORT)) {
            System.out.println("Servidor Remote Shell iniciado na porta " + REMOTE_SHELL_PORT);

            while (true) {
                byte[] receiveData = new byte[1024];
                byte[] sendData;

                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(receivePacket);

                String cmd = new String(receivePacket.getData());
                InetAddress IPAddress = receivePacket.getAddress();
                int port = receivePacket.getPort();

                String commandOutput = runCmd(cmd.trim());
                sendData = commandOutput.getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
                serverSocket.send(sendPacket);
            }
        }
    }

    public static String runCmd(String cmd) {
        StringBuilder output = new StringBuilder();

        ProcessBuilder processBuilder = new ProcessBuilder();
        processBuilder.command("bash", "-c", cmd);
        try {
            Process process = processBuilder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return output.toString();
    }
}
